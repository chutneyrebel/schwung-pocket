# Build Schwung Pocket IPA without installing Xcode on your Mac

This uses a GitHub-hosted macOS runner to compile the iOS app. You only need a GitHub account and a browser to start the build. The generated IPA is **unsigned**; it must be signed/installed with a sideloading tool such as Sideloadly before iOS can run it.

## One-time setup

1. Go to https://github.com/new and create a repository (for example, `SchwungPocket`). A private repository is fine if your account has available Actions minutes; a public repository may be simpler for a personal project. Do not upload Apple passwords, certificates, or provisioning profiles.
2. In the new repository, choose **Add file → Upload files** and upload `SchwungPocket-Starter.zip` from this kit. Commit the upload to the default branch.
3. Choose **Add file → Create new file**. In the filename box, enter exactly:

   `.github/workflows/build-ipa.yml`

4. Open the supplied `build-ipa.yml` file in this kit with any text editor, copy all its contents into the GitHub editor, and commit it to the default branch.
5. Open the repository's **Actions** tab. If prompted, enable Actions for the repository.
6. Select **Build Schwung Pocket IPA** in the left sidebar, click **Run workflow**, choose the default branch, and run it.
7. Open the run that appears. Wait for the green check mark. Under **Artifacts**, download `SchwungPocket-unsigned-ipa`. It downloads as a ZIP containing `SchwungPocket-unsigned.ipa`.

If the build fails, open the failed run and expand the red step to see the Xcode compiler log. No Xcode installation is needed on your Mac for this cloud build.

## Install the downloaded IPA

1. Unzip the downloaded GitHub artifact. You should see `SchwungPocket-unsigned.ipa`.
2. Download Sideloadly from its official site: https://sideloadly.io/ . Install it on the Mac.
3. Connect your iPhone to the Mac using USB and trust the computer when iOS asks.
4. Open Sideloadly, select your iPhone, drag `SchwungPocket-unsigned.ipa` into the IPA area, and follow Sideloadly's signing prompts using your own Apple ID. **Never send your Apple ID password to anyone or paste it into this README or a GitHub repository.**
5. With a free Apple account, personal sideloaded apps typically need re-signing every 7 days. A paid Apple Developer membership changes that renewal period. See Apple's account guidance: https://developer.apple.com/help/account/basics/about-your-developer-account/ and Sideloadly's FAQ: https://sideloadly.io/faq.html .
6. Keep the iPhone and Ableton Move on the same trusted Wi-Fi network. Open Schwung Pocket and test the connection. If `move.local:7700` does not resolve, enter the Move's LAN IP plus `:7700` in Settings.

## Important limitations

- This workflow builds the SwiftUI Xcode project on a GitHub-hosted macOS machine. It creates an **unsigned** `.ipa`, not an App Store-signed product. The IPA is not directly installable just by tapping it in Files; signing/sideloading is required.
- This initial app embeds the existing Schwung Manager interface and links to its mirror. It does not replace or modify Schwung on the Move.
- The project has not been compiled or device-tested by the authoring environment. The first cloud run is the real compile check; if it reports a compiler error, use the log to correct the source and rerun.
- Keep Schwung Manager on your local network only. Do not port-forward its management port to the public internet.
