
import SwiftUI
import WebKit

public struct BackupVaultScreen: View {
    @EnvironmentObject var connectionStore: MoveConnectionStore

    public init() {}

    public var body: some View {
        NavigationView {
            ZStack {
                Theme.background
                    .ignoresSafeArea()

                ManagerWebView(urlString: connectionStore.filesURL)
            }
            .navigationTitle("Files")
            .navigationBarTitleDisplayMode(.inline)
        }
    }
}
