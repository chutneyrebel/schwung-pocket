# Schwung Pocket v0.6.1

Schwung Pocket is an iPhone companion for Ableton Move running Schwung. It connects to Schwung Manager on the same local network.

## v0.6.1: Mirror workspace refinements

- Removed the navigation title and information button from the Mirror tab to reclaim vertical display space.
- Moved Move reachability status to the bottom of the Mirror tab, below the display and controls.
- Added persistent display layout options: Both (default), Top, and Bottom. The app attempts to identify the mirror portal's visual panels and show the selected panel. This is best-effort because the portal's internal HTML structure can vary by Schwung version.
- Added mobile viewport fitting in the Mirror tab and full-screen view. Large visual elements are constrained to the available screen dimensions, including when the portal switches its top display into its own full-screen mode, reducing the need for manual pinch-zoom.
- Added a native recording shortcut that looks for and activates the mirror portal's existing Record/Screen Recording control. It does not create a separate recorder. If the portal's button label or page structure differs, the app will report that it could not locate the control.
- Preserved previous full-screen controls, zoom, keep-awake, saved Move profiles, module discovery, Vault, and file import behaviour.

## Build

This is source code, not a precompiled IPA. Replace the root-level `SchwungPocket-Starter.zip` in the GitHub repository with this archive, keeping the filename unchanged. Leave the existing `.github/workflows/build-ipa.yml` workflow unchanged and run it through GitHub Actions. Download the generated IPA artifact and sign/install it as before.

## Verification status

Swift syntax parsing, `Info.plist` validation, static feature checks, and ZIP integrity checks are performed before release. A full Xcode build and live test against a physical Move/iPhone cannot be claimed unless the cloud workflow and on-device tests have been completed.
