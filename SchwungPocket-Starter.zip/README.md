# Schwung Pocket v0.6.4

Schwung Pocket is an iPhone companion shell for the Schwung Manager and Mirror portal on an Ableton Move.

## v0.6.4 updates
- Hides the mirror portal's header and connection-status chrome while the mirror is open, without intentionally hiding display containers.
- Retains references to both mirror display elements so switching between Both, Top, and Bottom continues to work after an element is hidden.
- Reapplies the selected display layout after device rotation and viewport resize, and resets single-display sizing when returning to Both.
- Adds an Enable Audio shortcut beside the recording controls. It attempts to activate a visible portal Unmute/Enable Audio control and unmute/play HTML audio or video elements.

## Build
Replace the root-level `SchwungPocket-Starter.zip` in your existing GitHub repository with this archive, keeping the same filename. Leave `.github/workflows/build-ipa.yml` unchanged and rerun the existing GitHub Actions workflow.

Swift syntax parsing, project/plist validation, and ZIP integrity checks passed. A full Xcode build and physical-device test have not been performed. The audio shortcut depends on the portal exposing an accessible unmute control or HTML media element; it cannot guarantee audio if the portal or device routes audio elsewhere.
