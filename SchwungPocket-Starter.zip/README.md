# Schwung Pocket v0.8.0 Experimental Studio

Schwung Pocket is an iPhone companion for an Ableton Move running Schwung.

## v0.8.0: Native Controls, Sample Lab & Groove Toolkit

- **Experimental Studio** is available from the Modules tab.
- **Native Controls** provides a native four-slider control-bank prototype, local value persistence, and target-selection UI. Live module parameter transmission is not enabled yet: it requires a confirmed Schwung control API or module-specific bridge. The interface labels this limitation rather than pretending the sliders control the Move.
- **Sample Lab** imports audio from Files into a private app-local shelf and auditions compatible files on the iPhone. It copies files into the app's documents area, leaving the original untouched.
- **Groove Toolkit** provides editable 16-step kick, clap and hat lanes, tempo and swing controls, randomise and four-on-the-floor presets, plus one-bar MIDI export for use in a DAW.
- Existing Home, Modules, Mirror, Manager, Settings and Sample & Set Vault flows are retained.

## Build through GitHub Actions

Replace the root-level `SchwungPocket-Starter.zip` in the existing repository with this archive, keeping the exact filename. Leave `.github/workflows/build-ipa.yml` unchanged and rerun the existing workflow.

## Validation notes

This source archive includes `SchwungPocket.xcodeproj/project.pbxproj` at the expected root-relative path. Swift syntax parsing, project/plist checks, and ZIP integrity should be run before relying on the build. A successful syntax parse is not the same as a full Xcode build or physical iPhone test. Native control values are local prototypes until a compatible live control bridge is implemented and verified.
