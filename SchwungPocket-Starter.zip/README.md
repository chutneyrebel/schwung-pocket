# Schwung Pocket v0.4.3

This update refines module discovery and navigation, and hardens importing files from the iPhone Files app.

## Changes

- Added a dedicated Modules tab in the bottom navigation, ordered Home, Modules, Mirror, Manager, Settings by default. Existing v0.4.2 navigation preferences are migrated to this new layout.
- Removed Vault from the bottom navigation. Open **Sample & Set Vault** from inside Settings instead.
- Moved Module discovery below **Your Module Shortcuts** and made it collapsible, so the list of discovered routes no longer pushes shortcuts off the screen.
- Grouped discovered routes into Schwung-style categories: Sound Generators, Audio FX, MIDI FX, Overtake, Tools, Utilities, and Other / Unclassified.
- Expanded the file importer's supported content types and added coordinated access for Files/iCloud provider URLs. Import results now show successful filenames and specific failure reasons rather than silently counting failed copies.

## Important limits

Module categories are inferred from the visible route/name text. The scanner reads links exposed in the Manager page's HTML, so it is not a guaranteed inventory of every installed module. Modules loaded dynamically by JavaScript or exposed only through undocumented endpoints may not appear. The official Schwung catalog categories include Sound Generators, Audio FX, MIDI FX, Overtake, Tools, and Utilities.

File import uses iOS's document picker and copies selected files into the app's local Downloads folder. The exact behavior still needs testing on an iPhone, especially with files stored in iCloud Drive or third-party file providers.

## Build and install

This ZIP contains source code, not a precompiled IPA. Replace the root-level `SchwungPocket-Starter.zip` in the GitHub repository with this archive while keeping that exact filename. Leave the existing GitHub Actions workflow unchanged, then run the cloud build workflow. Download the unsigned IPA artifact and sign/install it using the same method as the previous version.

## Checks performed

- Swift frontend syntax parse passed for all Swift source files.
- ZIP integrity check passed.
- Static checks confirmed the new tab order, Vault under Settings, collapsed discovery below shortcuts, module categories, and coordinated file import.

A full Xcode build and live test against a Move/iPhone have not been performed in this environment. Please run the cloud build and test file import on-device before treating this release as fully verified.
