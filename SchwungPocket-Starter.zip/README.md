# Schwung Pocket v0.8.1: Native Controls, Sample Lab & Groove Toolkit

Schwung Pocket is an iPhone companion for an Ableton Move running Schwung.

## v0.8.1: WebSocket-based native control prototype

- Adds a direct WebSocket client for the observed Schwung Remote UI endpoint: `/ws/remote-ui` on the configured Move host.
- Sends `subscribe` for a selected slot and reads `slot_info`, `hierarchy`, `chain_params`, and `param_update` messages.
- Builds native float sliders and enum selectors from discovered parameter metadata. Current parameter state is taken from incoming updates when available.
- Sends `set_param` messages when a native control changes and updates its displayed state from incoming `param_update` messages.
- Includes manual connect/disconnect and refresh controls. The connection is experimental and must be tested against the user's actual Schwung build; server handshake or origin requirements may vary.
- Retains Sample Lab import/audition and Groove Toolkit MIDI export from v0.8.0.

## Build through GitHub Actions

Replace the root-level `SchwungPocket-Starter.zip` in the existing repository with this archive, keeping the exact filename. Leave `.github/workflows/build-ipa.yml` unchanged and rerun the existing workflow.

## Validation notes

The source archive includes `SchwungPocket.xcodeproj/project.pbxproj` at the expected root-relative path. Swift frontend syntax parsing, plist lint, project structure checks, and ZIP integrity can be checked locally, but this environment does not have Apple's iOS SDK or Xcode. Therefore, this is not a confirmed full Xcode build or physical-device test. Treat live controls as experimental until the IPA is built, installed, and tested against the Move.
