# Schwung Pocket v0.4.2

This maintenance release implements the requested navigation, connection checklist, module discovery, and multi-Move profile changes.

## Changes

- Removed the duplicate Modules tab from bottom navigation. The bottom bar now contains Home, Manager, Mirror, Vault, and Settings, so Vault remains visible.
- Added a Settings control to reorder the five bottom navigation sections. Order is saved locally on the iPhone.
- Moved Automatic reconnection below Connection checklist.
- Connection checklist now updates checkmarks from connection status and the configured port. The checks run whenever the app's foreground connection monitor tests the selected Move. iOS does not guarantee periodic app execution while suspended in the background.
- Added a Module Hub entry on Home. It can scan the Schwung Manager page for same-host links exposed in the HTML and offer discovered routes as shortcuts.
- Added saved Move profiles with custom in-app names, selection, and a default Move marker. Names are local identifiers only and do not rename the physical Ableton Move.
- On launch, the app restores the selected saved Move, falling back to the default profile if needed.

## Important limits

Module discovery can only find links exposed in the Manager page's HTML. Schwung modules loaded dynamically by JavaScript, or exposed only through undocumented endpoints, may not appear. The scan is not a guaranteed inventory of all installed modules. A full module inventory requires access to the actual Move and knowledge of Schwung's supported module-discovery API.

Connection checklist items are inferred from the app's HTTP reachability test. The app cannot identify the Wi-Fi network type or directly inspect router client-isolation settings. A successful request only confirms that the configured Manager route is reachable at the time of the test.

## Build and install

This ZIP contains source code, not a precompiled IPA. Replace the existing root-level `SchwungPocket-Starter.zip` in the GitHub repository with this archive while keeping that filename, leave the working GitHub Actions workflow unchanged, then run the existing cloud build workflow. Download the unsigned IPA artifact and sign/install it using the same method as the previous version.

## Smoke test performed here

- Swift frontend parse passed for all Swift source files.
- Source ZIP integrity test passed.
- Static checks confirmed five bottom tabs, no duplicate Modules tab, saved profile/default keys, tab reordering, module scan action, and checklist ordering.

A full Xcode build and live test against the user's Move were not available in this environment. Please test the build on-device before treating the release as fully verified.
