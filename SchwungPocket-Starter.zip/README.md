# Schwung Pocket v0.6.3

Schwung Pocket is an iPhone companion shell for the Schwung Manager and Mirror portal on an Ableton Move.

## v0.6.3 updates
- Improved portal record/stop control detection and in-app recording state.
- Bottom-only mirror mode hides common portal headers and connection/status chrome.
- Mirror sizing reapplies on device rotation and viewport resize.
- Move connection status and connection check now sit with full-screen zoom controls.

## Build
Replace the root-level `SchwungPocket-Starter.zip` in the existing GitHub repository with this archive, keeping the same filename. Leave `.github/workflows/build-ipa.yml` unchanged and rerun the existing GitHub Actions workflow.

Syntax parsing and plist/archive checks passed. A full Xcode build and physical-device test have not been performed.
