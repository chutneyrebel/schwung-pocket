# Schwung Pocket v0.6.0

Schwung Pocket is an iPhone companion for Ableton Move running Schwung. It connects to Schwung Manager on the same local network.

## v0.6.0: Full-screen mirror and catalog-aware module categories

- Added a full-screen mirror mode that removes the app's navigation and connection UI from the mirrored display area. The full-screen view ignores safe areas and supports landscape orientation, so rotating the iPhone gives the mirror more usable space.
- Added mirror zoom controls (75% to 160%), a show/hide controls toggle, refresh, exit, and a Keep Awake setting.
- Added a saved setting to hide/show the connection strip in the regular Mirror tab.
- Module discovery now fetches the current public Schwung `module-catalog.json` when internet is available and uses each catalog entry's `component_type` to classify matching discovered routes into Sound Generators, Audio FX, MIDI FX, Overtake, Tools, and Utilities.
- Added an offline alias fallback for common catalog entries. Unknown routes remain in Other / Unclassified instead of being assigned a guessed category.
- Preserved existing v0.5.0 navigation, saved Move profiles, Vault under Settings, and file import functionality.

Catalog reference: https://schwung.dev/catalog.html and https://raw.githubusercontent.com/charlesvestal/schwung/main/module-catalog.json

## Build

This is source code, not a precompiled IPA. Replace the root-level `SchwungPocket-Starter.zip` in the GitHub repository with this archive, keeping the filename unchanged. Leave the existing `.github/workflows/build-ipa.yml` workflow unchanged and run it through GitHub Actions. Download the generated IPA artifact and sign/install it as before.

## Verification status

Swift syntax parsing, plist validation, static checks, and ZIP integrity checks are performed before release. A full Xcode build and live test against a physical Move/iPhone cannot be claimed unless the cloud workflow and on-device tests have been completed.
