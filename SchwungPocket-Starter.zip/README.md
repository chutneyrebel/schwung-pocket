# Schwung Pocket v0.5.0

Schwung Pocket is an iPhone companion for Ableton Move running Schwung. It connects to Schwung Manager on the same local network.

## v0.5.0: Move Mirror upgrade

- Reworked the Move Mirror screen with a compact connection-status strip to leave more room for the mirrored display.
- Added an in-screen connection check and a dedicated mirror refresh control.
- Added clearer status messaging for connected, checking, failed, and not-yet-checked states.
- Moved mirror setup guidance into an info alert, so it no longer permanently occupies display space.
- Preserved v0.4.3 module categories/discovery, Home → Modules → Mirror navigation, Vault under Settings, saved Move profiles, and file-import improvements.

## Build

This is source code, not a precompiled IPA. Replace the root-level `SchwungPocket-Starter.zip` in the GitHub repository with this archive, keeping the filename unchanged. Leave the existing `.github/workflows/build-ipa.yml` workflow unchanged and run it through GitHub Actions. Download the generated IPA artifact and sign/install it as before.

## Verification status

Swift syntax parsing and ZIP integrity checks are performed before release. A full Xcode build and live test against a physical Move/iPhone cannot be claimed unless the cloud workflow and on-device tests have been completed.
