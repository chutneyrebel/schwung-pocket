import SwiftUI
import UIKit
import WebKit

struct ManagerWebView: UIViewRepresentable {
    let url: URL

    func makeCoordinator() -> Coordinator {
        Coordinator()
    }

    func makeUIView(context: Context) -> WKWebView {
        let configuration = WKWebViewConfiguration()
        configuration.allowsInlineMediaPlayback = true
        let webView = WKWebView(frame: .zero, configuration: configuration)
        webView.backgroundColor = UIColor(red: 0.055, green: 0.067, blue: 0.09, alpha: 1.0)
        webView.isOpaque = false
        webView.scrollView.backgroundColor = UIColor(red: 0.055, green: 0.067, blue: 0.09, alpha: 1.0)
        webView.allowsBackForwardNavigationGestures = true
        webView.navigationDelegate = context.coordinator
        webView.uiDelegate = context.coordinator
        webView.load(URLRequest(url: url, cachePolicy: .useProtocolCachePolicy, timeoutInterval: 12))
        return webView
    }

    func updateUIView(_ webView: WKWebView, context: Context) {
        guard webView.url?.absoluteString != url.absoluteString else { return }
        webView.load(URLRequest(url: url, cachePolicy: .useProtocolCachePolicy, timeoutInterval: 12))
    }

    final class Coordinator: NSObject, WKNavigationDelegate, WKUIDelegate, WKDownloadDelegate {
        // WKWebView does not display JavaScript confirm()/alert() panels unless
        // the UI delegate implements them. Schwung Manager uses confirm() for bulk updates.
        func webView(_ webView: WKWebView, runJavaScriptConfirmPanelWithMessage message: String, initiatedByFrame frame: WKFrameInfo, completionHandler: @escaping (Bool) -> Void) {
            presentJavaScriptDialog(on: webView, title: "Schwung Manager", message: message, confirm: true) { accepted in
                completionHandler(accepted)
            }
        }

        func webView(_ webView: WKWebView, runJavaScriptAlertPanelWithMessage message: String, initiatedByFrame frame: WKFrameInfo, completionHandler: @escaping () -> Void) {
            presentJavaScriptDialog(on: webView, title: "Schwung Manager", message: message, confirm: false) { _ in
                completionHandler()
            }
        }

        private func presentJavaScriptDialog(on webView: WKWebView, title: String, message: String, confirm: Bool, completion: @escaping (Bool) -> Void) {
            DispatchQueue.main.async {
                guard let root = webView.window?.rootViewController else {
                    completion(false)
                    return
                }
                var presenter = root
                while let presented = presenter.presentedViewController { presenter = presented }
                let alert = UIAlertController(title: title, message: message, preferredStyle: .alert)
                if confirm {
                    alert.addAction(UIAlertAction(title: "Cancel", style: .cancel) { _ in completion(false) })
                    alert.addAction(UIAlertAction(title: "Continue", style: .default) { _ in completion(true) })
                } else {
                    alert.addAction(UIAlertAction(title: "OK", style: .default) { _ in completion(true) })
                }
                presenter.present(alert, animated: true)
            }
        }

        func webView(_ webView: WKWebView, didFail navigation: WKNavigation!, withError error: Error) {
            NSLog("Schwung Pocket web navigation failed: %@", error.localizedDescription)
        }

        func webView(_ webView: WKWebView, didFailProvisionalNavigation navigation: WKNavigation!, withError error: Error) {
            NSLog("Schwung Pocket could not load page: %@", error.localizedDescription)
        }

        func webView(_ webView: WKWebView, decidePolicyFor navigationAction: WKNavigationAction, decisionHandler: @escaping (WKNavigationActionPolicy) -> Void) {
            guard let url = navigationAction.request.url else {
                decisionHandler(.cancel)
                return
            }

            guard ["http", "https"].contains(url.scheme?.lowercased() ?? "") else {
                decisionHandler(.cancel)
                return
            }

            if navigationAction.shouldPerformDownload {
                decisionHandler(.download)
            } else {
                decisionHandler(.allow)
            }
        }

        func webView(_ webView: WKWebView, decidePolicyFor navigationResponse: WKNavigationResponse, decisionHandler: @escaping (WKNavigationResponsePolicy) -> Void) {
            decisionHandler(navigationResponse.canShowMIMEType ? .allow : .download)
        }

        func webView(_ webView: WKWebView, navigationAction: WKNavigationAction, didBecome download: WKDownload) {
            download.delegate = self
        }

        func webView(_ webView: WKWebView, navigationResponse: WKNavigationResponse, didBecome download: WKDownload) {
            download.delegate = self
        }

        // Some Manager links request a new window. Reuse the current in-app browser
        // rather than letting a tap silently do nothing.
        func webView(_ webView: WKWebView, createWebViewWith configuration: WKWebViewConfiguration, for navigationAction: WKNavigationAction, windowFeatures: WKWindowFeatures) -> WKWebView? {
            if navigationAction.targetFrame == nil, let url = navigationAction.request.url,
               ["http", "https"].contains(url.scheme?.lowercased() ?? "") {
                webView.load(URLRequest(url: url))
            }
            return nil
        }

        func download(_ download: WKDownload, decideDestinationUsing response: URLResponse, suggestedFilename: String, completionHandler: @escaping (URL?) -> Void) {
            guard let documents = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask).first else {
                completionHandler(nil)
                return
            }

            let folder = documents.appendingPathComponent("Downloads", isDirectory: true)
            do {
                try FileManager.default.createDirectory(at: folder, withIntermediateDirectories: true)
                let safeName = URL(fileURLWithPath: suggestedFilename).lastPathComponent
                let name = safeName.isEmpty ? "Schwung-Download" : safeName
                var destination = folder.appendingPathComponent(name)
                var suffix = 2
                while FileManager.default.fileExists(atPath: destination.path) {
                    let ext = destination.pathExtension
                    let stem = destination.deletingPathExtension().lastPathComponent
                    let nextName = ext.isEmpty ? "\(stem) (\(suffix))" : "\(stem) (\(suffix)).\(ext)"
                    destination = folder.appendingPathComponent(nextName)
                    suffix += 1
                }
                completionHandler(destination)
            } catch {
                NSLog("Schwung Pocket could not prepare Downloads folder: %@", error.localizedDescription)
                completionHandler(nil)
            }
        }

        func downloadDidFinish(_ download: WKDownload) {
            NotificationCenter.default.post(name: .schwungPocketDownloadFinished, object: nil)
        }

        func download(_ download: WKDownload, didFailWithError error: Error, resumeData: Data?) {
            NSLog("Schwung Pocket download failed: %@", error.localizedDescription)
        }
    }
}

extension Notification.Name {
    static let schwungPocketDownloadFinished = Notification.Name("SchwungPocketDownloadFinished")
}
