import SwiftUI
import UIKit
import UniformTypeIdentifiers

struct BackupVaultScreen: View {
    @State private var downloadedFiles: [URL] = []
    @State private var backupFiles: [URL] = []
    @State private var isImporting = false
    @State private var alertMessage = ""
    @State private var showingAlert = false
    @State private var deleteTarget: URL?
    @State private var shareTarget: ShareTarget?

    private var documentsURL: URL {
        FileManager.default.urls(for: .documentDirectory, in: .userDomainMask).first
            ?? URL(fileURLWithPath: NSTemporaryDirectory(), isDirectory: true)
    }

    private var downloadsURL: URL { documentsURL.appendingPathComponent("Downloads", isDirectory: true) }
    private var backupsURL: URL { documentsURL.appendingPathComponent("Backups", isDirectory: true) }

    var body: some View {
        NavigationStack {
            ScrollView(showsIndicators: false) {
                VStack(alignment: .leading, spacing: 18) {
                    introCard
                    downloadSection
                    backupsSection
                    limitationCard
                }
                .padding(18)
                .padding(.bottom, 26)
            }
            .background(Theme.background.ignoresSafeArea())
            .navigationTitle("Backup Vault")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .navigationBarTrailing) {
                    Button { isImporting = true } label: {
                        Image(systemName: "square.and.arrow.down")
                    }
                    .accessibilityLabel("Import files from Files")
                }
                ToolbarItem(placement: .navigationBarLeading) {
                    Button { refresh() } label: {
                        Image(systemName: "arrow.clockwise")
                    }
                    .accessibilityLabel("Refresh Vault")
                }
            }
            .onAppear(perform: refresh)
            .onReceive(NotificationCenter.default.publisher(for: .schwungPocketDownloadFinished)) { _ in
                refresh()
            }
            .fileImporter(
                isPresented: $isImporting,
                allowedContentTypes: [.item],
                allowsMultipleSelection: true,
                onCompletion: importFiles
            )
            .alert("Schwung Pocket", isPresented: $showingAlert) {
                Button("OK", role: .cancel) { }
            } message: {
                Text(alertMessage)
            }
            .sheet(item: $shareTarget) { target in
                ActivitySheet(activityItems: [target.url])
            }
            .confirmationDialog(
                "Delete this saved backup?",
                isPresented: Binding(
                    get: { deleteTarget != nil },
                    set: { if !$0 { deleteTarget = nil } }
                ),
                titleVisibility: .visible
            ) {
                Button("Delete backup", role: .destructive) {
                    if let target = deleteTarget {
                        deleteBackup(target)
                    }
                    deleteTarget = nil
                }
                Button("Cancel", role: .cancel) { deleteTarget = nil }
            } message: {
                Text("This removes the local snapshot from this iPhone. It does not delete the original file in Downloads or on Move.")
            }
        }
    }

    private var introCard: some View {
        PocketCard {
            VStack(alignment: .leading, spacing: 12) {
                HStack(spacing: 10) {
                    Image(systemName: "archivebox.fill")
                        .font(.system(size: 24, weight: .semibold))
                        .foregroundStyle(Theme.accent)
                    VStack(alignment: .leading, spacing: 3) {
                        Text("YOUR LOCAL FILE VAULT")
                            .font(.system(size: 10, weight: .heavy))
                            .tracking(1.6)
                            .foregroundStyle(Theme.muted)
                        Text("Keep a safe copy before editing.")
                            .font(.system(size: 17, weight: .semibold, design: .rounded))
                            .foregroundStyle(.white)
                    }
                }
                Text("Files downloaded from Schwung Manager are stored on this iPhone. Create a dated snapshot, restore a snapshot to Downloads, or export it through the iOS share sheet.")
                    .font(.system(size: 13))
                    .lineSpacing(4)
                    .foregroundStyle(Theme.muted)
                Button { isImporting = true } label: {
                    Label("Import from Files", systemImage: "plus.circle.fill")
                        .font(.system(size: 14, weight: .bold))
                        .foregroundStyle(Theme.background)
                        .frame(maxWidth: .infinity)
                        .padding(.vertical, 13)
                        .background(Theme.accent, in: RoundedRectangle(cornerRadius: 13, style: .continuous))
                }
            }
        }
    }

    private var downloadSection: some View {
        VStack(alignment: .leading, spacing: 11) {
            sectionHeader("DOWNLOADS", detail: "\(downloadedFiles.count) files")
            if downloadedFiles.isEmpty {
                emptyState(
                    symbol: "folder",
                    title: "No local files yet",
                    detail: "Download a file inside Schwung Manager or import one using the button above."
                )
            } else {
                VStack(spacing: 9) {
                    ForEach(downloadedFiles, id: \.path) { file in
                        fileRow(file, isBackup: false)
                    }
                }
            }
        }
    }

    private var backupsSection: some View {
        VStack(alignment: .leading, spacing: 11) {
            sectionHeader("SAVED SNAPSHOTS", detail: "\(backupFiles.count) backups")
            if backupFiles.isEmpty {
                emptyState(
                    symbol: "archivebox",
                    title: "Your Vault is empty",
                    detail: "Tap the archive icon beside a downloaded file to save its first snapshot."
                )
            } else {
                VStack(spacing: 9) {
                    ForEach(backupFiles, id: \.path) { file in
                        fileRow(file, isBackup: true)
                    }
                }
            }
        }
    }

    private var limitationCard: some View {
        PocketCard {
            VStack(alignment: .leading, spacing: 8) {
                Label("What this backup covers", systemImage: "info.circle")
                    .font(.system(size: 15, weight: .semibold))
                    .foregroundStyle(.white)
                Text("The Vault snapshots files already stored on the iPhone. It does not automatically back up every file or Set on Move. To protect a Move file, first download or export it through Schwung Manager, then create a snapshot here. Restoring puts a copy into the iPhone's Downloads folder; it does not upload anything back to Move.")
                    .font(.system(size: 12))
                    .lineSpacing(4)
                    .foregroundStyle(Theme.muted)
            }
        }
    }

    private func sectionHeader(_ title: String, detail: String) -> some View {
        HStack(alignment: .firstTextBaseline) {
            Text(title)
                .font(.system(size: 10, weight: .heavy))
                .tracking(1.7)
                .foregroundStyle(Theme.muted)
            Spacer()
            Text(detail)
                .font(.system(size: 11, weight: .medium))
                .foregroundStyle(Theme.muted.opacity(0.85))
        }
    }

    private func emptyState(symbol: String, title: String, detail: String) -> some View {
        HStack(spacing: 12) {
            Image(systemName: symbol)
                .font(.system(size: 22))
                .foregroundStyle(Theme.muted)
                .frame(width: 42, height: 42)
                .background(Theme.surfaceRaised, in: RoundedRectangle(cornerRadius: 12, style: .continuous))
            VStack(alignment: .leading, spacing: 4) {
                Text(title).font(.system(size: 14, weight: .semibold)).foregroundStyle(.white)
                Text(detail).font(.system(size: 12)).foregroundStyle(Theme.muted).fixedSize(horizontal: false, vertical: true)
            }
        }
        .padding(14)
        .frame(maxWidth: .infinity, alignment: .leading)
        .background(Theme.surface, in: RoundedRectangle(cornerRadius: 18, style: .continuous))
    }

    private func fileRow(_ url: URL, isBackup: Bool) -> some View {
        HStack(spacing: 11) {
            Image(systemName: isBackup ? "archivebox.fill" : fileSymbol(for: url))
                .font(.system(size: 18, weight: .medium))
                .foregroundStyle(isBackup ? Theme.accent : Theme.blue)
                .frame(width: 40, height: 40)
                .background((isBackup ? Theme.accent : Theme.blue).opacity(0.12), in: RoundedRectangle(cornerRadius: 12, style: .continuous))
            VStack(alignment: .leading, spacing: 4) {
                Text(isBackup ? originalName(forBackup: url) : url.lastPathComponent)
                    .font(.system(size: 13, weight: .semibold))
                    .foregroundStyle(.white)
                    .lineLimit(2)
                HStack(spacing: 6) {
                    Text(fileSize(url))
                    if isBackup, let date = backupDate(url) {
                        Text("·")
                        Text(date, style: .date)
                    }
                }
                .font(.system(size: 10))
                .foregroundStyle(Theme.muted)
            }
            Spacer(minLength: 4)
            if isBackup {
                Button { shareTarget = ShareTarget(url: url) } label: {
                    Image(systemName: "square.and.arrow.up")
                        .font(.system(size: 15, weight: .semibold))
                        .foregroundStyle(Theme.blue)
                        .frame(width: 34, height: 38)
                }
                .accessibilityLabel("Export backup")
                Menu {
                    Button { restoreBackup(url) } label: { Label("Restore to Downloads", systemImage: "arrow.uturn.backward") }
                    Button(role: .destructive) { deleteTarget = url } label: { Label("Delete backup", systemImage: "trash") }
                } label: {
                    Image(systemName: "ellipsis")
                        .font(.system(size: 17, weight: .bold))
                        .foregroundStyle(.white)
                        .frame(width: 30, height: 38)
                }
            } else {
                Button { shareTarget = ShareTarget(url: url) } label: {
                    Image(systemName: "square.and.arrow.up")
                        .font(.system(size: 15, weight: .semibold))
                        .foregroundStyle(Theme.blue)
                        .frame(width: 30, height: 38)
                }
                .accessibilityLabel("Share or export file")
                Menu {
                    Button { createSnapshot(of: url) } label: { Label("Create snapshot", systemImage: "archivebox") }
                } label: {
                    Image(systemName: "ellipsis")
                        .font(.system(size: 17, weight: .bold))
                        .foregroundStyle(.white)
                        .frame(width: 28, height: 38)
                }
            }
        }
        .padding(.horizontal, 12)
        .padding(.vertical, 10)
        .background(Theme.surface, in: RoundedRectangle(cornerRadius: 17, style: .continuous))
    }

    private func fileSymbol(for url: URL) -> String {
        let ext = url.pathExtension.lowercased()
        if ["wav", "aiff", "aif", "mp3", "m4a", "flac", "ogg"].contains(ext) { return "waveform" }
        if ["ablbundle", "als", "adv", "adg"].contains(ext) { return "music.note.list" }
        if ["zip", "tar", "gz"].contains(ext) { return "doc.zipper" }
        return "doc"
    }

    private func fileSize(_ url: URL) -> String {
        let values = try? url.resourceValues(forKeys: [.fileSizeKey])
        return ByteCountFormatter.string(fromByteCount: Int64(values?.fileSize ?? 0), countStyle: .file)
    }

    private func backupDate(_ url: URL) -> Date? {
        let prefix = url.lastPathComponent.components(separatedBy: "__").first ?? ""
        let formatter = DateFormatter()
        formatter.locale = Locale(identifier: "en_US_POSIX")
        formatter.dateFormat = "yyyyMMdd-HHmmss"
        return formatter.date(from: prefix)
    }

    private func originalName(forBackup url: URL) -> String {
        let name = url.lastPathComponent
        guard let separator = name.range(of: "__") else { return name }
        return String(name[separator.upperBound...])
    }

    private func refresh() {
        do {
            try FileManager.default.createDirectory(at: downloadsURL, withIntermediateDirectories: true)
            try FileManager.default.createDirectory(at: backupsURL, withIntermediateDirectories: true)
            downloadedFiles = try listFiles(in: downloadsURL)
            backupFiles = try listFiles(in: backupsURL)
        } catch {
            showMessage("Could not read the local file folders: \(error.localizedDescription)")
        }
    }

    private func listFiles(in folder: URL) throws -> [URL] {
        try FileManager.default.contentsOfDirectory(at: folder, includingPropertiesForKeys: [.isDirectoryKey, .fileSizeKey, .contentModificationDateKey], options: [.skipsHiddenFiles])
            .filter { url in
                let values = try? url.resourceValues(forKeys: [.isDirectoryKey])
                return values?.isDirectory == false
            }
            .sorted { lhs, rhs in
                let leftDate = (try? lhs.resourceValues(forKeys: [.contentModificationDateKey]))?.contentModificationDate ?? .distantPast
                let rightDate = (try? rhs.resourceValues(forKeys: [.contentModificationDateKey]))?.contentModificationDate ?? .distantPast
                return leftDate > rightDate
            }
    }

    private func createSnapshot(of source: URL) {
        do {
            try FileManager.default.createDirectory(at: backupsURL, withIntermediateDirectories: true)
            let formatter = DateFormatter()
            formatter.locale = Locale(identifier: "en_US_POSIX")
            formatter.dateFormat = "yyyyMMdd-HHmmss"
            let requestedName = "\(formatter.string(from: Date()))__\(source.lastPathComponent)"
            let destination = uniqueURL(named: requestedName, in: backupsURL)
            try FileManager.default.copyItem(at: source, to: destination)
            refresh()
            showMessage("Snapshot saved: \(source.lastPathComponent)")
        } catch {
            showMessage("Could not create the snapshot: \(error.localizedDescription)")
        }
    }

    private func restoreBackup(_ backup: URL) {
        do {
            try FileManager.default.createDirectory(at: downloadsURL, withIntermediateDirectories: true)
            let requestedName = originalName(forBackup: backup)
            let destination = uniqueURL(named: requestedName, in: downloadsURL)
            try FileManager.default.copyItem(at: backup, to: destination)
            refresh()
            showMessage("Restored a copy to Downloads as \(destination.lastPathComponent). It has not been uploaded to Move.")
        } catch {
            showMessage("Could not restore the snapshot: \(error.localizedDescription)")
        }
    }

    private func deleteBackup(_ backup: URL) {
        do {
            try FileManager.default.removeItem(at: backup)
            refresh()
            showMessage("Backup deleted.")
        } catch {
            showMessage("Could not delete the backup: \(error.localizedDescription)")
        }
    }

    private func importFiles(_ result: Result<[URL], Error>) {
        switch result {
        case .failure(let error):
            showMessage("Import was cancelled or failed: \(error.localizedDescription)")
        case .success(let urls):
            do {
                try FileManager.default.createDirectory(at: downloadsURL, withIntermediateDirectories: true)
                var importedCount = 0
                for source in urls {
                    let accessed = source.startAccessingSecurityScopedResource()
                    defer { if accessed { source.stopAccessingSecurityScopedResource() } }
                    let destination = uniqueURL(named: source.lastPathComponent, in: downloadsURL)
                    try FileManager.default.copyItem(at: source, to: destination)
                    importedCount += 1
                }
                refresh()
                showMessage("Imported \(importedCount) file(s) into Downloads. Create snapshots from the list whenever you need a backup.")
            } catch {
                refresh()
                showMessage("Some files may have been imported, but the operation stopped: \(error.localizedDescription)")
            }
        }
    }

    private func uniqueURL(named name: String, in folder: URL) -> URL {
        var candidate = folder.appendingPathComponent(name)
        var suffix = 2
        while FileManager.default.fileExists(atPath: candidate.path) {
            let original = URL(fileURLWithPath: name)
            let ext = original.pathExtension
            let stem = original.deletingPathExtension().lastPathComponent
            let uniqueName = ext.isEmpty ? "\(stem) (\(suffix))" : "\(stem) (\(suffix)).\(ext)"
            candidate = folder.appendingPathComponent(uniqueName)
            suffix += 1
        }
        return candidate
    }

    private func showMessage(_ message: String) {
        alertMessage = message
        showingAlert = true
    }
}


private struct ShareTarget: Identifiable {
    let id = UUID()
    let url: URL
}

private struct ActivitySheet: UIViewControllerRepresentable {
    let activityItems: [Any]

    func makeUIViewController(context: Context) -> UIActivityViewController {
        UIActivityViewController(activityItems: activityItems, applicationActivities: nil)
    }

    func updateUIViewController(_ uiViewController: UIActivityViewController, context: Context) { }
}
