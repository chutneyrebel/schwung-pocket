import SwiftUI

private enum PocketTab: Hashable {
    case home, manager, mirror, vault, settings
}

struct ContentView: View {
    @ObservedObject var device: MoveConnectionStore
    @State private var selectedTab: PocketTab = .home

    var body: some View {
        TabView(selection: $selectedTab) {
            HomeScreen(
                device: device,
                openManager: { selectedTab = .manager },
                openMirror: { selectedTab = .mirror },
                openVault: { selectedTab = .vault },
                openSettings: { selectedTab = .settings }
            )
            .tabItem { Label("Home", systemImage: "waveform.path") }
            .tag(PocketTab.home)

            ManagerScreen(device: device)
                .tabItem { Label("Manager", systemImage: "slider.horizontal.3") }
                .tag(PocketTab.manager)

            MirrorScreen(device: device)
                .tabItem { Label("Mirror", systemImage: "rectangle.inset.filled") }
                .tag(PocketTab.mirror)

            BackupVaultScreen()
                .tabItem { Label("Vault", systemImage: "archivebox") }
                .tag(PocketTab.vault)

            ConnectionSettingsScreen(device: device)
                .tabItem { Label("Settings", systemImage: "gearshape") }
                .tag(PocketTab.settings)
        }
        .toolbarBackground(Theme.background, for: .tabBar)
        .toolbarBackground(.visible, for: .tabBar)
        .background(Theme.background.ignoresSafeArea())
    }
}

private enum FavoriteDestination: String, CaseIterable, Identifiable {
    case manager, mirror, vault, settings

    var id: String { rawValue }

    var title: String {
        switch self {
        case .manager: return "Manager"
        case .mirror: return "Screen mirror"
        case .vault: return "Backup Vault"
        case .settings: return "Connection settings"
        }
    }

    var subtitle: String {
        switch self {
        case .manager: return "Modules, files, config"
        case .mirror: return "Move display + LEDs"
        case .vault: return "Snapshots and imports"
        case .settings: return "Device address and status"
        }
    }

    var symbol: String {
        switch self {
        case .manager: return "slider.horizontal.3"
        case .mirror: return "rectangle.inset.filled"
        case .vault: return "archivebox"
        case .settings: return "network"
        }
    }

    var tint: Color {
        switch self {
        case .manager: return Theme.violet
        case .mirror: return Theme.blue
        case .vault: return Theme.accent
        case .settings: return Theme.warning
        }
    }
}

private struct HomeScreen: View {
    @ObservedObject var device: MoveConnectionStore
    let openManager: () -> Void
    let openMirror: () -> Void
    let openVault: () -> Void
    let openSettings: () -> Void

    @AppStorage("SchwungPocket.FavouriteActions") private var favouriteIDs = "manager,mirror,vault"
    @State private var showingFavouriteEditor = false

    private var favouriteDestinations: [FavoriteDestination] {
        let selected = Set(favouriteIDs.split(separator: ",").map(String.init))
        return FavoriteDestination.allCases.filter { selected.contains($0.rawValue) }
    }

    var body: some View {
        NavigationStack {
            ScrollView(showsIndicators: false) {
                VStack(alignment: .leading, spacing: 22) {
                    header
                    connectionCard
                    favouriteActions
                    noteWorkflowCard
                    footer
                }
                .padding(.horizontal, 18)
                .padding(.top, 14)
                .padding(.bottom, 28)
            }
            .background(Theme.background.ignoresSafeArea())
            .toolbar(.hidden, for: .navigationBar)
            .sheet(isPresented: $showingFavouriteEditor) {
                FavouriteActionsEditor(favouriteIDs: $favouriteIDs)
                    .preferredColorScheme(.dark)
            }
        }
    }

    private var header: some View {
        VStack(alignment: .leading, spacing: 10) {
            HStack(alignment: .top) {
                VStack(alignment: .leading, spacing: 5) {
                    Text("SCHWUNG")
                        .font(.system(size: 12, weight: .black, design: .rounded))
                        .tracking(3.6)
                        .foregroundStyle(Theme.accent)
                    Text("Pocket")
                        .font(.system(size: 38, weight: .bold, design: .rounded))
                        .foregroundStyle(.white)
                }
                Spacer()
                ZStack {
                    RoundedRectangle(cornerRadius: 18, style: .continuous)
                        .fill(Theme.surfaceRaised)
                        .frame(width: 58, height: 58)
                    Image(systemName: "waveform.path")
                        .font(.system(size: 25, weight: .semibold))
                        .foregroundStyle(Theme.accent)
                }
            }
            Text("Your Move, one tap away.")
                .font(.system(size: 16, weight: .medium))
                .foregroundStyle(Theme.muted)
        }
        .padding(.bottom, 2)
    }

    private var connectionCard: some View {
        PocketCard {
            VStack(alignment: .leading, spacing: 14) {
                HStack(spacing: 10) {
                    ZStack {
                        RoundedRectangle(cornerRadius: 12, style: .continuous)
                            .fill(Theme.accent.opacity(0.13))
                            .frame(width: 42, height: 42)
                        Image(systemName: "dot.radiowaves.left.and.right")
                            .font(.system(size: 18, weight: .semibold))
                            .foregroundStyle(Theme.accent)
                    }
                    VStack(alignment: .leading, spacing: 3) {
                        Text("ABLETON MOVE")
                            .font(.system(size: 10, weight: .bold))
                            .tracking(1.8)
                            .foregroundStyle(Theme.muted)
                        Text(device.status.title)
                            .font(.system(size: 17, weight: .semibold))
                            .foregroundStyle(.white)
                    }
                    Spacer(minLength: 4)
                    statusDot
                }
                Text(device.status.detail)
                    .font(.system(size: 13))
                    .foregroundStyle(Theme.muted)
                    .fixedSize(horizontal: false, vertical: true)

                if let lastCheckedAt = device.lastCheckedAt {
                    Text("Last checked \(lastCheckedAt, style: .relative)")
                        .font(.system(size: 11, weight: .medium))
                        .foregroundStyle(Theme.muted.opacity(0.85))
                } else {
                    Text("Auto-checks when the app is open")
                        .font(.system(size: 11, weight: .medium))
                        .foregroundStyle(Theme.muted.opacity(0.85))
                }

                HStack(spacing: 10) {
                    Button {
                        Task { await device.checkConnection() }
                    } label: {
                        HStack(spacing: 8) {
                            if device.status == .checking {
                                ProgressView().tint(Theme.background)
                            } else {
                                Image(systemName: "antenna.radiowaves.left.and.right")
                            }
                            Text(device.status == .checking ? "Checking" : "Check now")
                        }
                        .font(.system(size: 14, weight: .bold))
                        .foregroundStyle(Theme.background)
                        .frame(maxWidth: .infinity)
                        .padding(.vertical, 13)
                        .background(Theme.accent, in: RoundedRectangle(cornerRadius: 13, style: .continuous))
                    }
                    .disabled(device.status == .checking)

                    Button(action: openSettings) {
                        Image(systemName: "slider.horizontal.3")
                            .font(.system(size: 16, weight: .semibold))
                            .foregroundStyle(.white)
                            .frame(width: 48, height: 44)
                            .background(Theme.surfaceRaised, in: RoundedRectangle(cornerRadius: 13, style: .continuous))
                    }
                    .accessibilityLabel("Connection settings")
                }
            }
        }
    }

    @ViewBuilder
    private var statusDot: some View {
        switch device.status {
        case .connected:
            Circle().fill(Theme.success).frame(width: 9, height: 9)
        case .checking:
            ProgressView().tint(Theme.accent).scaleEffect(0.85)
        case .failed:
            Circle().fill(Color.red.opacity(0.9)).frame(width: 9, height: 9)
        case .idle:
            Circle().fill(Theme.muted.opacity(0.65)).frame(width: 9, height: 9)
        }
    }

    private var favouriteActions: some View {
        VStack(alignment: .leading, spacing: 12) {
            HStack(alignment: .firstTextBaseline) {
                VStack(alignment: .leading, spacing: 4) {
                    Text("QUICK CONTROL")
                        .font(.system(size: 10, weight: .heavy))
                        .tracking(1.8)
                        .foregroundStyle(Theme.muted)
                    Text("Your favourites")
                        .font(.system(size: 19, weight: .semibold, design: .rounded))
                        .foregroundStyle(.white)
                }
                Spacer()
                Button("EDIT") { showingFavouriteEditor = true }
                    .font(.system(size: 10, weight: .heavy))
                    .tracking(1.4)
                    .foregroundStyle(Theme.accent)
            }

            LazyVGrid(columns: [GridItem(.flexible(), spacing: 12), GridItem(.flexible(), spacing: 12)], spacing: 12) {
                ForEach(favouriteDestinations) { destination in
                    ActionTile(
                        title: destination.title,
                        subtitle: destination.subtitle,
                        symbol: destination.symbol,
                        tint: destination.tint,
                        action: { open(destination) }
                    )
                }
            }

            if favouriteDestinations.isEmpty {
                Text("No shortcuts selected. Tap Edit to add your favourites.")
                    .font(.system(size: 13))
                    .foregroundStyle(Theme.muted)
                    .padding(14)
                    .frame(maxWidth: .infinity, alignment: .leading)
                    .background(Theme.surface, in: RoundedRectangle(cornerRadius: 16, style: .continuous))
            }
        }
    }

    private func open(_ destination: FavoriteDestination) {
        switch destination {
        case .manager: openManager()
        case .mirror: openMirror()
        case .vault: openVault()
        case .settings: openSettings()
        }
    }

    private var noteWorkflowCard: some View {
        PocketCard {
            VStack(alignment: .leading, spacing: 11) {
                HStack(spacing: 8) {
                    Image(systemName: "music.note")
                        .foregroundStyle(Theme.accent)
                    Text("MOVE ↔ NOTE")
                        .font(.system(size: 11, weight: .bold))
                        .tracking(1.6)
                        .foregroundStyle(.white)
                }
                Text("Sketch on your phone. Shape it on Move.")
                    .font(.system(size: 18, weight: .semibold, design: .rounded))
                    .foregroundStyle(.white)
                Text("Use Ableton Cloud to move compatible Sets between Note and Move. Ableton Link syncs timing, not clips or projects. Schwung-only instruments will not appear as instruments in Note, so capture their sound as audio when you need a portable version.")
                    .font(.system(size: 13))
                    .lineSpacing(4)
                    .foregroundStyle(Theme.muted)
            }
        }
    }

    private var footer: some View {
        HStack(alignment: .top, spacing: 8) {
            Image(systemName: "lock.shield")
                .foregroundStyle(Theme.muted)
            Text("Local-network companion. Schwung Manager itself has no password, so use it only on a trusted network.")
                .font(.system(size: 11))
                .foregroundStyle(Theme.muted)
                .fixedSize(horizontal: false, vertical: true)
        }
        .padding(.horizontal, 3)
    }
}

private struct FavouriteActionsEditor: View {
    @Binding var favouriteIDs: String
    @Environment(\.dismiss) private var dismiss
    @State private var selected: Set<String>

    init(favouriteIDs: Binding<String>) {
        self._favouriteIDs = favouriteIDs
        let initial = Set(favouriteIDs.wrappedValue.split(separator: ",").map(String.init))
        self._selected = State(initialValue: initial)
    }

    var body: some View {
        NavigationStack {
            List {
                Section("Choose shortcuts") {
                    ForEach(FavoriteDestination.allCases) { destination in
                        Button {
                            if selected.contains(destination.rawValue) {
                                selected.remove(destination.rawValue)
                            } else {
                                selected.insert(destination.rawValue)
                            }
                        } label: {
                            HStack(spacing: 12) {
                                Image(systemName: destination.symbol)
                                    .foregroundStyle(destination.tint)
                                    .frame(width: 28)
                                VStack(alignment: .leading, spacing: 3) {
                                    Text(destination.title).foregroundStyle(.primary)
                                    Text(destination.subtitle).font(.caption).foregroundStyle(.secondary)
                                }
                                Spacer()
                                if selected.contains(destination.rawValue) {
                                    Image(systemName: "checkmark.circle.fill")
                                        .foregroundStyle(Theme.accent)
                                } else {
                                    Image(systemName: "circle")
                                        .foregroundStyle(.secondary)
                                }
                            }
                            .contentShape(Rectangle())
                        }
                        .buttonStyle(.plain)
                    }
                }
                Section {
                    Text("These shortcuts only open app screens. Manager subpages remain inside the original Schwung web interface.")
                        .font(.footnote)
                        .foregroundStyle(.secondary)
                }
            }
            .scrollContentBackground(.hidden)
            .background(Theme.background)
            .navigationTitle("Quick Control")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .cancellationAction) {
                    Button("Cancel") { dismiss() }
                }
                ToolbarItem(placement: .confirmationAction) {
                    Button("Save") {
                        favouriteIDs = FavoriteDestination.allCases
                            .filter { selected.contains($0.rawValue) }
                            .map(\.rawValue)
                            .joined(separator: ",")
                        dismiss()
                    }
                    .fontWeight(.semibold)
                }
            }
        }
    }
}

private struct ActionTile: View {
    let title: String
    let subtitle: String
    let symbol: String
    let tint: Color
    let action: () -> Void

    var body: some View {
        Button(action: action) {
            VStack(alignment: .leading, spacing: 10) {
                Image(systemName: symbol)
                    .font(.system(size: 20, weight: .semibold))
                    .foregroundStyle(tint)
                    .frame(width: 42, height: 42)
                    .background(tint.opacity(0.13), in: RoundedRectangle(cornerRadius: 13, style: .continuous))
                Text(title)
                    .font(.system(size: 16, weight: .semibold))
                    .foregroundStyle(.white)
                Text(subtitle)
                    .font(.system(size: 11))
                    .foregroundStyle(Theme.muted)
                    .lineLimit(2)
                    .multilineTextAlignment(.leading)
                Spacer(minLength: 0)
                HStack {
                    Text("OPEN")
                        .font(.system(size: 9, weight: .heavy))
                        .tracking(1.4)
                        .foregroundStyle(tint)
                    Spacer()
                    Image(systemName: "arrow.up.right")
                        .font(.system(size: 11, weight: .bold))
                        .foregroundStyle(tint)
                }
            }
            .padding(14)
            .frame(maxWidth: .infinity, minHeight: 154, alignment: .leading)
            .background(Theme.surface, in: RoundedRectangle(cornerRadius: 20, style: .continuous))
            .overlay {
                RoundedRectangle(cornerRadius: 20, style: .continuous)
                    .strokeBorder(Color.white.opacity(0.055), lineWidth: 1)
            }
        }
        .buttonStyle(.plain)
    }
}

private struct ManagerScreen: View {
    @ObservedObject var device: MoveConnectionStore
    @State private var reloadToken = UUID()

    var body: some View {
        NavigationStack {
            Group {
                if let url = device.managerURL {
                    ManagerWebView(url: url)
                        .id(reloadToken)
                        .ignoresSafeArea(edges: .bottom)
                } else {
                    InvalidAddressView()
                }
            }
            .background(Theme.background)
            .navigationTitle("Schwung Manager")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .navigationBarTrailing) {
                    Button { reloadToken = UUID() } label: { Image(systemName: "arrow.clockwise") }
                        .accessibilityLabel("Reload Manager")
                }
            }
        }
    }
}

private struct MirrorScreen: View {
    @ObservedObject var device: MoveConnectionStore
    @State private var reloadToken = UUID()

    var body: some View {
        NavigationStack {
            Group {
                if let url = device.mirrorURL {
                    VStack(spacing: 0) {
                        HStack(spacing: 8) {
                            Image(systemName: "info.circle")
                            Text("Enable Mirror Display in Schwung Global Settings if the display is blank.")
                                .font(.system(size: 12))
                        }
                        .foregroundStyle(Theme.muted)
                        .padding(.horizontal, 15)
                        .padding(.vertical, 10)
                        .frame(maxWidth: .infinity, alignment: .leading)
                        .background(Theme.surface)
                        ManagerWebView(url: url)
                            .id(reloadToken)
                    }
                } else {
                    InvalidAddressView()
                }
            }
            .background(Theme.background)
            .navigationTitle("Move Mirror")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .navigationBarTrailing) {
                    Button { reloadToken = UUID() } label: { Image(systemName: "arrow.clockwise") }
                        .accessibilityLabel("Reload mirror")
                }
            }
        }
    }
}

private struct ConnectionSettingsScreen: View {
    @ObservedObject var device: MoveConnectionStore
    @FocusState private var addressFocused: Bool

    var body: some View {
        NavigationStack {
            ScrollView(showsIndicators: false) {
                VStack(alignment: .leading, spacing: 18) {
                    PocketCard {
                        VStack(alignment: .leading, spacing: 12) {
                            Text("MOVE ADDRESS")
                                .font(.system(size: 11, weight: .heavy))
                                .tracking(1.6)
                                .foregroundStyle(Theme.muted)
                            TextField("move.local:7700", text: $device.addressText)
                                .font(.system(size: 16, weight: .medium, design: .monospaced))
                                .textInputAutocapitalization(.never)
                                .autocorrectionDisabled()
                                .keyboardType(.URL)
                                .submitLabel(.done)
                                .focused($addressFocused)
                                .padding(13)
                                .background(Theme.background, in: RoundedRectangle(cornerRadius: 12, style: .continuous))
                            Text("Default: move.local:7700. Replace it with your Move's local IP address and port 7700 if the .local name does not resolve.")
                                .font(.system(size: 12))
                                .lineSpacing(3)
                                .foregroundStyle(Theme.muted)
                            HStack(spacing: 10) {
                                Button {
                                    addressFocused = false
                                    Task { await device.checkConnection() }
                                } label: {
                                    Text("Test connection")
                                        .font(.system(size: 14, weight: .bold))
                                        .foregroundStyle(Theme.background)
                                        .frame(maxWidth: .infinity)
                                        .padding(.vertical, 13)
                                        .background(Theme.accent, in: RoundedRectangle(cornerRadius: 13, style: .continuous))
                                }
                                .disabled(device.status == .checking)
                                Button("Reset") { device.resetAddress() }
                                    .font(.system(size: 14, weight: .semibold))
                                    .foregroundStyle(.white)
                                    .padding(.horizontal, 16)
                                    .padding(.vertical, 13)
                                    .background(Theme.surfaceRaised, in: RoundedRectangle(cornerRadius: 13, style: .continuous))
                            }
                        }
                    }

                    PocketCard {
                        VStack(alignment: .leading, spacing: 9) {
                            Label("Automatic reconnection", systemImage: "arrow.triangle.2.circlepath")
                                .font(.system(size: 16, weight: .semibold))
                                .foregroundStyle(.white)
                            Text("While Schwung Pocket is open, it checks the Move connection periodically and retries after the app returns to the foreground. iOS suspends most app activity when the app is in the background.")
                                .font(.system(size: 13))
                                .lineSpacing(4)
                                .foregroundStyle(Theme.muted)
                        }
                    }

                    PocketCard {
                        VStack(alignment: .leading, spacing: 9) {
                            Label("Connection checklist", systemImage: "checklist")
                                .font(.system(size: 16, weight: .semibold))
                                .foregroundStyle(.white)
                            checklistRow("Move is powered on and Schwung has finished loading.")
                            checklistRow("iPhone and Move are on the same Wi-Fi network.")
                            checklistRow("The address includes port 7700, not stock Move Manager's port 80.")
                            checklistRow("Avoid guest Wi-Fi or networks with client isolation enabled.")
                        }
                    }

                    PocketCard {
                        VStack(alignment: .leading, spacing: 8) {
                            Label("Privacy & network safety", systemImage: "lock.shield")
                                .font(.system(size: 16, weight: .semibold))
                                .foregroundStyle(.white)
                            Text("Schwung Manager does not require a password. Keep Move on a trusted local network; do not forward port 7700 to the internet. This app does not add authentication to the Manager.")
                                .font(.system(size: 13))
                                .lineSpacing(4)
                                .foregroundStyle(Theme.muted)
                        }
                    }
                }
                .padding(18)
            }
            .background(Theme.background.ignoresSafeArea())
            .navigationTitle("Connection")
            .navigationBarTitleDisplayMode(.inline)
        }
    }

    private func checklistRow(_ text: String) -> some View {
        HStack(alignment: .top, spacing: 9) {
            Image(systemName: "circle")
                .font(.system(size: 11, weight: .medium))
                .foregroundStyle(Theme.accent)
                .padding(.top, 3)
            Text(text)
                .font(.system(size: 12))
                .lineSpacing(3)
                .foregroundStyle(Theme.muted)
        }
    }
}

private struct InvalidAddressView: View {
    var body: some View {
        VStack(spacing: 12) {
            Image(systemName: "network.slash")
                .font(.system(size: 36))
                .foregroundStyle(Theme.warning)
            Text("Check the Move address")
                .font(.system(size: 20, weight: .semibold))
                .foregroundStyle(.white)
            Text("Open Settings and enter a valid address such as move.local:7700.")
                .font(.system(size: 14))
                .multilineTextAlignment(.center)
                .foregroundStyle(Theme.muted)
        }
        .padding(28)
        .frame(maxWidth: .infinity, maxHeight: .infinity)
        .background(Theme.background)
    }
}
