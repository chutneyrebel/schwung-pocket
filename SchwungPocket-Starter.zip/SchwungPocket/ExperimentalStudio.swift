import SwiftUI
import UIKit
import AVFoundation
import UniformTypeIdentifiers

struct ExperimentalStudioScreen: View {
    @ObservedObject var device: MoveConnectionStore
    @State private var section = StudioSection.controls
    var body: some View {
        NavigationStack {
            ScrollView(showsIndicators: false) {
                VStack(alignment: .leading, spacing: 18) {
                    VStack(alignment: .leading, spacing: 6) {
                        Text("SCHWUNG POCKET / EXPERIMENTAL")
                            .font(.system(size: 10, weight: .heavy)).tracking(1.8).foregroundStyle(Theme.accent)
                        Text("Studio Lab").font(.system(size: 30, weight: .bold, design: .rounded)).foregroundStyle(.white)
                        Text("Three small tools for shaping, testing and sketching ideas.").font(.system(size: 14)).foregroundStyle(Theme.muted)
                    }
                    Picker("Studio tool", selection: $section) {
                        ForEach(StudioSection.allCases) { item in Text(item.title).tag(item) }
                    }.pickerStyle(.segmented)
                    switch section {
                    case .controls: NativeControlPrototype(device: device)
                    case .samples: SampleLabView()
                    case .groove: GrooveToolkitView()
                    }
                    Text("EXPERIMENTAL BUILD · Save your originals before testing workflows.")
                        .font(.system(size: 10, weight: .semibold)).tracking(0.8).foregroundStyle(Theme.muted)
                        .frame(maxWidth: .infinity, alignment: .center).padding(.top, 4)
                }.padding(18)
            }
            .background(Theme.background.ignoresSafeArea())
            .toolbarBackground(Theme.background, for: .navigationBar)
            .toolbarBackground(.visible, for: .navigationBar)
        }
        .preferredColorScheme(.dark)
    }
}

private enum StudioSection: String, CaseIterable, Identifiable {
    case controls, samples, groove
    var id: String { rawValue }
    var title: String { switch self { case .controls: "Controls"; case .samples: "Sample Lab"; case .groove: "Groove" } }
}

private struct NativeControlPrototype: View {
    @ObservedObject var device: MoveConnectionStore
    @StateObject private var remote = SchwungRemoteControlStore()

    var body: some View {
        VStack(alignment: .leading, spacing: 14) {
            PocketCard {
                VStack(alignment: .leading, spacing: 12) {
                    Label("Live native controls", systemImage: "slider.horizontal.3")
                        .font(.system(size: 17, weight: .bold)).foregroundStyle(.white)
                    Text("Connect directly to Schwung's Remote UI WebSocket. The app discovers the selected slot's parameter metadata and sends changes to the Move.")
                        .font(.system(size: 13)).lineSpacing(3).foregroundStyle(Theme.muted)
                    HStack(spacing: 8) {
                        Circle().fill(remote.isConnected ? Theme.success : Theme.warning).frame(width: 7, height: 7)
                        Text(remote.status).font(.system(size: 11, weight: .medium)).foregroundStyle(Theme.muted)
                    }
                    HStack(spacing: 10) {
                        Button {
                            if remote.isConnected { remote.disconnect() }
                            else { remote.connect(address: device.addressText) }
                        } label: {
                            Label(remote.isConnected ? "Disconnect" : "Connect to Schwung", systemImage: remote.isConnected ? "xmark.circle.fill" : "dot.radiowaves.left.and.right")
                                .font(.system(size: 13, weight: .bold))
                        }.buttonStyle(StudioPrimaryButton())
                        if remote.isConnected {
                            Button { remote.refreshSubscription() } label: {
                                Label("Refresh", systemImage: "arrow.clockwise").font(.system(size: 12, weight: .semibold))
                            }.buttonStyle(StudioSecondaryButton())
                        }
                    }
                }
            }

            PocketCard {
                VStack(alignment: .leading, spacing: 10) {
                    Text("SLOT & INSTRUMENT").font(.system(size: 10, weight: .heavy)).tracking(1.4).foregroundStyle(Theme.muted)
                    HStack {
                        Stepper("Slot \(remote.slot)", value: Binding(get: { remote.slot }, set: { remote.selectSlot($0) }), in: 0...7)
                            .font(.system(size: 14, weight: .semibold)).foregroundStyle(.white)
                        Spacer(minLength: 8)
                        Text(remote.instrumentName.isEmpty ? "Waiting for slot info" : remote.instrumentName)
                            .font(.system(size: 13, weight: .bold)).foregroundStyle(Theme.accent)
                    }
                    if remote.levels.count > 1 {
                        Picker("Parameter group", selection: Binding(get: { remote.selectedLevelID }, set: { remote.selectedLevelID = $0 })) {
                            ForEach(remote.levels) { level in Text(level.name).tag(level.id) }
                        }.pickerStyle(.menu).tint(Theme.accent)
                    }
                    Text(remote.parameters.isEmpty ? "Connect, then wait for slot metadata." : "\(remote.visibleParameters.count) controls in this group · values sync from the Move")
                        .font(.system(size: 11)).foregroundStyle(Theme.muted)
                }
            }

            if remote.parameters.isEmpty {
                PocketCard {
                    VStack(alignment: .leading, spacing: 8) {
                        Image(systemName: "waveform.path.ecg").font(.system(size: 25)).foregroundStyle(Theme.violet)
                        Text("Ready to discover controls").font(.system(size: 16, weight: .semibold)).foregroundStyle(.white)
                        Text("The native control bank will populate after the WebSocket returns slot_info, hierarchy, chain_params and param_update messages.")
                            .font(.system(size: 12)).lineSpacing(3).foregroundStyle(Theme.muted)
                    }
                }
            } else {
                PocketCard {
                    VStack(alignment: .leading, spacing: 17) {
                        HStack {
                            Text(remote.currentLevelName.uppercased()).font(.system(size: 10, weight: .heavy)).tracking(1.4).foregroundStyle(Theme.accent)
                            Spacer()
                            Text("LIVE").font(.system(size: 9, weight: .heavy)).tracking(1).foregroundStyle(Theme.success)
                        }
                        ForEach(remote.visibleParameters) { parameter in
                            remoteControl(parameter)
                        }
                    }
                }
            }
            Text("Experimental protocol integration. Test at a safe listening level; parameter names and ranges depend on the loaded module.")
                .font(.system(size: 10)).lineSpacing(2).foregroundStyle(Theme.muted)
        }
        .onDisappear { remote.disconnect() }
    }

    @ViewBuilder
    private func remoteControl(_ parameter: SchwungRemoteParameter) -> some View {
        VStack(alignment: .leading, spacing: 5) {
            HStack(alignment: .firstTextBaseline) {
                Text(parameter.shortName.isEmpty ? parameter.name : parameter.shortName)
                    .font(.system(size: 13, weight: .semibold)).foregroundStyle(.white)
                Spacer()
                Text(remote.displayValue(for: parameter))
                    .font(.system(size: 11, weight: .medium, design: .monospaced)).foregroundStyle(Theme.accent)
            }
            if parameter.type == "enum", !parameter.options.isEmpty {
                Picker(parameter.name, selection: Binding(
                    get: { remote.currentEnumIndex(for: parameter) },
                    set: { remote.setEnum($0, for: parameter) }
                )) {
                    ForEach(Array(parameter.options.enumerated()), id: \.offset) { item in
                        Text(item.element).tag(item.offset)
                    }
                }
                .pickerStyle(.segmented)
                .tint(Theme.accent)
            } else if parameter.type == "float" {
                Slider(value: Binding(
                    get: { remote.currentDouble(for: parameter) },
                    set: { remote.setFloat($0, for: parameter) }
                ), in: parameter.minimum...max(parameter.maximum, parameter.minimum + 0.0001), step: max(parameter.step, 0.0001))
                .tint(Theme.accent)
            } else {
                Text("Unsupported control type: \(parameter.type)").font(.system(size: 10)).foregroundStyle(Theme.muted)
            }
        }
    }
}

private struct SchwungRemoteParameter: Identifiable, Hashable {
    let component: String
    let key: String
    let name: String
    let shortName: String
    let type: String
    let minimum: Double
    let maximum: Double
    let step: Double
    let defaultValue: Double
    let options: [String]

    var id: String { component + ":" + key }
    var wireKey: String { key.contains(":") ? key : component + ":" + key }
}

private struct SchwungRemoteLevel: Identifiable, Hashable {
    let id: String
    let name: String
    let parameterKeys: [String]
}

@MainActor
private final class SchwungRemoteControlStore: ObservableObject {
    @Published private(set) var isConnected = false
    @Published private(set) var status = "Not connected"
    @Published private(set) var slot = 2
    @Published private(set) var instrumentName = ""
    @Published private(set) var parameters: [SchwungRemoteParameter] = []
    @Published private(set) var levels: [SchwungRemoteLevel] = []
    @Published var selectedLevelID = "root"
    @Published private(set) var values: [String: String] = [:]

    private var socket: URLSessionWebSocketTask?
    private var connectionID = UUID()

    var currentLevelName: String {
        levels.first(where: { $0.id == selectedLevelID })?.name ?? instrumentName
    }

    var visibleParameters: [SchwungRemoteParameter] {
        guard let level = levels.first(where: { $0.id == selectedLevelID }), !level.parameterKeys.isEmpty else { return parameters }
        return parameters.filter { level.parameterKeys.contains($0.key) || level.parameterKeys.contains($0.wireKey) }
    }

    func connect(address: String) {
        disconnect(updateStatus: false)
        guard let url = websocketURL(address: address) else {
            status = "Invalid Move address"
            return
        }
        let newID = UUID()
        connectionID = newID
        var request = URLRequest(url: url)
        let originScheme = url.scheme == "wss" ? "https" : "http"
        let originPort = url.port ?? (originScheme == "https" ? 443 : 80)
        request.setValue("\(originScheme)://\(url.host ?? "move.local"):\(originPort)", forHTTPHeaderField: "Origin")
        let newSocket = URLSession.shared.webSocketTask(with: request)
        socket = newSocket
        status = "Connecting to \(url.host ?? "Move")…"
        newSocket.resume()
        Task { [weak self] in
            guard let self else { return }
            do {
                try await newSocket.send(.string(self.jsonString(["type": "subscribe", "slot": self.slot])))
                guard self.connectionID == newID else { return }
                self.isConnected = true
                self.status = "Connected · waiting for slot metadata"
                await self.receiveMessages(from: newSocket, connectionID: newID)
            } catch {
                guard self.connectionID == newID else { return }
                self.isConnected = false
                self.status = "Connection failed: \(error.localizedDescription)"
                self.socket = nil
            }
        }
    }

    func disconnect(updateStatus: Bool = true) {
        connectionID = UUID()
        socket?.cancel(with: .goingAway, reason: nil)
        socket = nil
        isConnected = false
        if updateStatus { status = "Disconnected" }
    }

    func selectSlot(_ newSlot: Int) {
        let safeSlot = min(max(newSlot, 0), 7)
        guard safeSlot != slot else { return }
        slot = safeSlot
        instrumentName = ""
        parameters = []
        levels = []
        values = [:]
        selectedLevelID = "root"
        if isConnected { send(["type": "subscribe", "slot": slot]); status = "Subscribed to slot \(slot)" }
    }

    func refreshSubscription() {
        guard isConnected else { return }
        parameters = []
        levels = []
        send(["type": "subscribe", "slot": slot])
        status = "Refreshing slot metadata…"
    }

    func currentDouble(for parameter: SchwungRemoteParameter) -> Double {
        Double(values[parameter.wireKey] ?? values[parameter.key] ?? "") ?? parameter.defaultValue
    }

    func currentEnumIndex(for parameter: SchwungRemoteParameter) -> Int {
        let raw = values[parameter.wireKey] ?? values[parameter.key]
        return min(max(Int(Double(raw ?? "") ?? parameter.defaultValue), 0), max(parameter.options.count - 1, 0))
    }

    func displayValue(for parameter: SchwungRemoteParameter) -> String {
        if parameter.type == "enum" {
            let index = currentEnumIndex(for: parameter)
            return parameter.options.indices.contains(index) ? parameter.options[index] : "—"
        }
        let value = currentDouble(for: parameter)
        return String(format: "%.2f", value)
    }

    func setFloat(_ proposed: Double, for parameter: SchwungRemoteParameter) {
        let clamped = min(max(proposed, parameter.minimum), parameter.maximum)
        let stepped = parameter.minimum + (((clamped - parameter.minimum) / max(parameter.step, 0.0001)).rounded() * max(parameter.step, 0.0001))
        let decimals = min(max(String(parameter.step).split(separator: ".").last?.count ?? 2, 0), 4)
        let text = String(format: "%.*f", decimals, min(max(stepped, parameter.minimum), parameter.maximum))
        values[parameter.wireKey] = text
        send(["type": "set_param", "slot": slot, "key": parameter.wireKey, "value": text])
    }

    func setEnum(_ index: Int, for parameter: SchwungRemoteParameter) {
        let safeIndex = min(max(index, 0), max(parameter.options.count - 1, 0))
        let text = String(safeIndex)
        values[parameter.wireKey] = text
        send(["type": "set_param", "slot": slot, "key": parameter.wireKey, "value": text])
    }

    private func websocketURL(address: String) -> URL? {
        let trimmed = address.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !trimmed.isEmpty else { return nil }
        let input = trimmed.contains("://") ? trimmed : "http://\(trimmed)"
        guard var components = URLComponents(string: input), let host = components.host, !host.isEmpty else { return nil }
        let scheme = (components.scheme ?? "http").lowercased()
        components.scheme = (scheme == "https" || scheme == "wss") ? "wss" : "ws"
        components.path = "/ws/remote-ui"
        components.query = nil
        components.fragment = nil
        return components.url
    }

    private func send(_ message: [String: Any]) {
        guard let socket else { return }
        let text = jsonString(message)
        Task {
            do { try await socket.send(.string(text)) }
            catch {
                if self.socket === socket {
                    self.isConnected = false
                    self.status = "Send failed: \(error.localizedDescription)"
                }
            }
        }
    }

    private func jsonString(_ message: [String: Any]) -> String {
        guard let data = try? JSONSerialization.data(withJSONObject: message, options: [.fragmentsAllowed]),
              let text = String(data: data, encoding: .utf8) else { return "{}" }
        return text
    }

    private func receiveMessages(from socket: URLSessionWebSocketTask, connectionID id: UUID) async {
        while !Task.isCancelled {
            do {
                let message = try await socket.receive()
                let text: String
                switch message {
                case .string(let string): text = string
                case .data(let data): text = String(data: data, encoding: .utf8) ?? ""
                @unknown default: continue
                }
                handleMessage(text)
            } catch {
                guard connectionID == id else { return }
                isConnected = false
                status = "Disconnected: \(error.localizedDescription)"
                self.socket = nil
                return
            }
        }
    }

    private func handleMessage(_ text: String) {
        guard let data = text.data(using: .utf8),
              let message = (try? JSONSerialization.jsonObject(with: data)) as? [String: Any],
              let type = message["type"] as? String else { return }
        let messageSlot = message["slot"] as? Int
        if let messageSlot, messageSlot != slot { return }

        switch type {
        case "slot_info":
            instrumentName = message["synth"] as? String ?? instrumentName
            status = "Connected · \(instrumentName.isEmpty ? "slot \(slot)" : instrumentName)"
        case "hierarchy":
            guard let data = message["data"] as? [String: Any], let rawLevels = data["levels"] as? [String: Any] else { return }
            var found: [SchwungRemoteLevel] = []
            for (id, value) in rawLevels {
                guard let item = value as? [String: Any] else { continue }
                let name = item["name"] as? String ?? id.capitalized
                let keys = (item["params"] as? [Any] ?? []).compactMap { $0 as? String }
                found.append(SchwungRemoteLevel(id: id, name: name, parameterKeys: keys))
            }
            found.sort { left, right in
                if left.id == "root" { return true }
                if right.id == "root" { return false }
                return left.name.localizedCaseInsensitiveCompare(right.name) == .orderedAscending
            }
            levels = found
            if !found.contains(where: { $0.id == selectedLevelID }) { selectedLevelID = found.first?.id ?? "root" }
        case "chain_params":
            let component = message["component"] as? String ?? "synth"
            guard let items = message["data"] as? [[String: Any]] else { return }
            let parsed = items.compactMap { item -> SchwungRemoteParameter? in
                guard let key = item["key"] as? String else { return nil }
                let options = item["options"] as? [String] ?? []
                return SchwungRemoteParameter(
                    component: component,
                    key: key,
                    name: item["name"] as? String ?? key.replacingOccurrences(of: "_", with: " ").capitalized,
                    shortName: item["short_name"] as? String ?? "",
                    type: item["type"] as? String ?? "float",
                    minimum: (item["min"] as? NSNumber)?.doubleValue ?? 0,
                    maximum: (item["max"] as? NSNumber)?.doubleValue ?? 1,
                    step: (item["step"] as? NSNumber)?.doubleValue ?? 0.01,
                    defaultValue: (item["default"] as? NSNumber)?.doubleValue ?? 0,
                    options: options
                )
            }
            parameters = parameters.filter { $0.component != component } + parsed
            parameters.sort { $0.name.localizedCaseInsensitiveCompare($1.name) == .orderedAscending }
        case "param_update":
            if let params = message["params"] as? [String: Any] {
                for (key, value) in params {
                    if let string = value as? String { values[key] = string }
                    else if let number = value as? NSNumber { values[key] = number.stringValue }
                }
            }
        default:
            break
        }
    }
}

private struct SampleLabView: View {
    @State private var samples: [LabSample] = []
    @State private var showingImporter = false
    @State private var player: AVAudioPlayer?
    @State private var playingID: UUID?
    @State private var errorMessage: String?
    private var directory: URL { FileManager.default.urls(for: .documentDirectory, in: .userDomainMask)[0].appendingPathComponent("SampleLab", isDirectory: true) }
    var body: some View {
        VStack(alignment: .leading, spacing: 14) {
            PocketCard {
                VStack(alignment: .leading, spacing: 9) {
                    Label("Sample Lab", systemImage: "waveform").font(.system(size: 17, weight: .bold)).foregroundStyle(.white)
                    Text("Import audio from Files, audition it, and keep a lightweight local sample shelf on this iPhone.").font(.system(size: 13)).lineSpacing(3).foregroundStyle(Theme.muted)
                    Button { showingImporter = true } label: { Label("Import audio", systemImage: "plus.circle.fill").font(.system(size: 14, weight: .bold)) }.buttonStyle(StudioPrimaryButton())
                }
            }
            if let errorMessage { Text(errorMessage).font(.system(size: 12)).foregroundStyle(Theme.warning) }
            if samples.isEmpty {
                PocketCard { VStack(alignment: .leading, spacing: 7) { Image(systemName: "tray").font(.system(size: 25)).foregroundStyle(Theme.violet); Text("Your sample shelf is empty").font(.system(size: 16, weight: .semibold)).foregroundStyle(.white); Text("Add WAV, AIFF, MP3, M4A or another audio format supported by iOS.").font(.system(size: 12)).foregroundStyle(Theme.muted) } }
            } else {
                ForEach(samples) { sample in
                    PocketCard {
                        HStack(spacing: 12) {
                            Button { audition(sample) } label: { Image(systemName: playingID == sample.id ? "stop.fill" : "play.fill").font(.system(size: 16, weight: .bold)).foregroundStyle(Theme.background).frame(width: 42, height: 42).background(Theme.accent, in: RoundedRectangle(cornerRadius: 12)) }.buttonStyle(.plain)
                            VStack(alignment: .leading, spacing: 4) { Text(sample.name).font(.system(size: 14, weight: .semibold)).foregroundStyle(.white).lineLimit(2); Text(sample.url.pathExtension.uppercased() + " · local file").font(.system(size: 11)).foregroundStyle(Theme.muted) }
                            Spacer(minLength: 0)
                        }
                    }
                }
            }
        }
        .fileImporter(isPresented: $showingImporter, allowedContentTypes: [.audio, .mp3, .wav, .aiff, .mpeg4Audio], allowsMultipleSelection: true, onCompletion: importFiles)
        .onAppear(perform: loadSamples)
    }
    private func loadSamples() {
        try? FileManager.default.createDirectory(at: directory, withIntermediateDirectories: true)
        let urls = (try? FileManager.default.contentsOfDirectory(at: directory, includingPropertiesForKeys: nil)) ?? []
        samples = urls.filter { !$0.hasDirectoryPath && $0.pathExtension.lowercased() != "json" }.sorted { $0.lastPathComponent.localizedCaseInsensitiveCompare($1.lastPathComponent) == .orderedAscending }.map { LabSample(name: $0.deletingPathExtension().lastPathComponent, url: $0) }
    }
    private func importFiles(_ result: Result<[URL], Error>) {
        do {
            let urls = try result.get()
            try FileManager.default.createDirectory(at: directory, withIntermediateDirectories: true)
            for source in urls {
                let access = source.startAccessingSecurityScopedResource(); defer { if access { source.stopAccessingSecurityScopedResource() } }
                let safeName = source.lastPathComponent
                var destination = directory.appendingPathComponent(safeName)
                if FileManager.default.fileExists(atPath: destination.path) { destination = directory.appendingPathComponent(UUID().uuidString + "-" + safeName) }
                try FileManager.default.copyItem(at: source, to: destination)
            }
            errorMessage = nil; loadSamples()
        } catch { errorMessage = "Import failed: \(error.localizedDescription)" }
    }
    private func audition(_ sample: LabSample) {
        if playingID == sample.id { player?.stop(); player = nil; playingID = nil; return }
        do { try AVAudioSession.sharedInstance().setCategory(.playback, mode: .default, options: [.mixWithOthers]); try AVAudioSession.sharedInstance().setActive(true); player = try AVAudioPlayer(contentsOf: sample.url); player?.prepareToPlay(); player?.play(); playingID = sample.id }
        catch { errorMessage = "Can't preview this file: \(error.localizedDescription)" }
    }
}
private struct LabSample: Identifiable { let id = UUID(); let name: String; let url: URL }

private struct GrooveToolkitView: View {
    @State private var bpm = 128.0
    @State private var swing = 0.12
    @State private var steps = Array(repeating: false, count: 16)
    @State private var exportURL: URL?
    @State private var message: String?
    private let rows = [("KICK", "circle.fill"), ("CLAP", "circle.grid.2x2.fill"), ("HAT", "circle")]
    @State private var kick = [true, false, false, false, true, false, false, false, true, false, false, false, true, false, false, false]
    @State private var clap = [false, false, false, false, true, false, false, false, false, false, false, false, true, false, false, false]
    @State private var hat = (0..<16).map { $0 % 2 == 0 }
    var body: some View {
        VStack(alignment: .leading, spacing: 14) {
            PocketCard {
                VStack(alignment: .leading, spacing: 10) {
                    Label("Groove Toolkit", systemImage: "circle.grid.3x3.fill").font(.system(size: 17, weight: .bold)).foregroundStyle(.white)
                    HStack { Text("TEMPO").font(.system(size: 10, weight: .heavy)).tracking(1.2).foregroundStyle(Theme.muted); Spacer(); Text("\(Int(bpm)) BPM").font(.system(size: 16, weight: .bold, design: .rounded)).foregroundStyle(Theme.accent) }
                    Slider(value: $bpm, in: 70...180, step: 1).tint(Theme.accent)
                    HStack { Text("SWING").font(.system(size: 10, weight: .heavy)).tracking(1.2).foregroundStyle(Theme.muted); Spacer(); Text("\(Int(swing * 100))%").font(.system(size: 13, design: .monospaced)).foregroundStyle(Theme.accent) }
                    Slider(value: $swing, in: 0...0.45).tint(Theme.violet)
                }
            }
            grooveRow("KICK", pattern: $kick, tint: Theme.accent)
            grooveRow("CLAP", pattern: $clap, tint: Theme.violet)
            grooveRow("HAT", pattern: $hat, tint: Theme.blue)
            HStack(spacing: 8) {
                Button("Randomise") { randomise() }.buttonStyle(StudioSecondaryButton())
                Button("4-on-floor") { kick = (0..<16).map { $0 % 4 == 0 }; clap = (0..<16).map { $0 % 8 == 4 }; hat = (0..<16).map { $0 % 2 == 0 } }.buttonStyle(StudioSecondaryButton())
            }
            PocketCard {
                VStack(alignment: .leading, spacing: 10) {
                    Text("EXPORT MIDI").font(.system(size: 10, weight: .heavy)).tracking(1.3).foregroundStyle(Theme.muted)
                    Text("Export a one-bar, three-lane MIDI groove. Swing is applied to offbeat events. Import the MIDI into your DAW to audition and edit it.").font(.system(size: 12)).lineSpacing(3).foregroundStyle(Theme.muted)
                    Button { exportMIDI() } label: { Label("Create MIDI file", systemImage: "square.and.arrow.up").font(.system(size: 14, weight: .bold)) }.buttonStyle(StudioPrimaryButton())
                    if let exportURL { ShareLink(item: exportURL) { Label("Share \(exportURL.lastPathComponent)", systemImage: "arrowshape.turn.up.right").font(.system(size: 13, weight: .semibold)) }.tint(Theme.accent) }
                    if let message { Text(message).font(.system(size: 11)).foregroundStyle(Theme.muted) }
                }
            }
        }
    }
    private func grooveRow(_ title: String, pattern: Binding<[Bool]>, tint: Color) -> some View {
        PocketCard {
            VStack(alignment: .leading, spacing: 10) {
                HStack { Text(title).font(.system(size: 11, weight: .heavy)).tracking(1.4).foregroundStyle(tint); Spacer(); Text("16 STEPS").font(.system(size: 9, weight: .bold)).foregroundStyle(Theme.muted) }
                LazyVGrid(columns: Array(repeating: GridItem(.flexible(), spacing: 5), count: 8), spacing: 7) {
                    ForEach(0..<16, id: \.self) { i in
                        Button { pattern.wrappedValue[i].toggle() } label: {
                            Text("\(i + 1)").font(.system(size: 10, weight: .bold, design: .monospaced)).foregroundStyle(pattern.wrappedValue[i] ? Theme.background : Theme.muted)
                                .frame(maxWidth: .infinity).frame(height: 34).background(pattern.wrappedValue[i] ? tint : Theme.surfaceRaised, in: RoundedRectangle(cornerRadius: 8))
                        }.buttonStyle(.plain)
                    }
                }
            }
        }
    }
    private func randomise() {
        kick = (0..<16).map { $0 % 4 == 0 || Int.random(in: 0..<100) < 8 }
        clap = (0..<16).map { $0 % 8 == 4 || Int.random(in: 0..<100) < 7 }
        hat = (0..<16).map { $0 % 2 == 0 || Int.random(in: 0..<100) < 35 }
    }
    private func exportMIDI() {
        let ticksPerQuarter = 480
        let ticksPerBar = ticksPerQuarter * 4
        let microseconds = Int(60_000_000 / bpm)
        var events: [(Int, [UInt8])] = []
        let tempo: [UInt8] = [0x00, 0xFF, 0x51, 0x03, UInt8((microseconds >> 16) & 255), UInt8((microseconds >> 8) & 255), UInt8(microseconds & 255)]
        events.append((0, tempo))
        let lanes: [([Bool], UInt8, UInt8)] = [(kick, 36, 9), (clap, 39, 9), (hat, 42, 9)]
        for (pattern, note, channel) in lanes {
            for index in 0..<16 where pattern[index] {
                var tick = index * (ticksPerBar / 16)
                if index % 2 == 1 { tick += Int(Double(ticksPerQuarter / 2) * swing) }
                events.append((tick, [0x00, UInt8(0x90 | channel), note, 100]))
                events.append((tick + 90, [0x00, UInt8(0x80 | channel), note, 0]))
            }
        }
        events.sort { $0.0 < $1.0 }
        var track: [UInt8] = []
        var lastTick = 0
        for (tick, bytes) in events {
            let delta = max(0, tick - lastTick); lastTick = tick
            let encoded = Self.variableLength(delta)
            track.append(contentsOf: encoded)
            if bytes.count == 7 && bytes[1] == 0xFF { track.append(contentsOf: Array(bytes.dropFirst())) }
            else { track.append(contentsOf: Array(bytes.dropFirst())) }
        }
        track.append(contentsOf: [0x00, 0xFF, 0x2F, 0x00])
        var data = Data("MThd".utf8); data.append(contentsOf: [0, 0, 0, 6, 0, 0, 0, 1, UInt8(ticksPerQuarter >> 8), UInt8(ticksPerQuarter & 255)])
        data.append(contentsOf: Array("MTrk".utf8)); let length = UInt32(track.count)
        data.append(contentsOf: [UInt8((length >> 24) & 255), UInt8((length >> 16) & 255), UInt8((length >> 8) & 255), UInt8(length & 255)]); data.append(contentsOf: track)
        let url = FileManager.default.temporaryDirectory.appendingPathComponent("SchwungPocket-Groove-\(Int(bpm))bpm.mid")
        do { try data.write(to: url, options: .atomic); exportURL = url; message = "MIDI created. Use Share to save it to Files or send it to your DAW." }
        catch { message = "MIDI export failed: \(error.localizedDescription)" }
    }
    private static func variableLength(_ value: Int) -> [UInt8] {
        var buffer = value & 0x7F; var remaining = value >> 7
        while remaining > 0 { buffer <<= 8; buffer |= ((remaining & 0x7F) | 0x80); remaining >>= 7 }
        var result: [UInt8] = []
        while true { result.append(UInt8(buffer & 255)); if buffer & 0x80 != 0 { buffer >>= 8 } else { break } }
        return result
    }
}

private struct StudioPrimaryButton: ButtonStyle {
    func makeBody(configuration: Configuration) -> some View { configuration.label.foregroundStyle(Theme.background).padding(.horizontal, 14).padding(.vertical, 11).background(Theme.accent.opacity(configuration.isPressed ? 0.75 : 1), in: RoundedRectangle(cornerRadius: 12)) }
}
private struct StudioSecondaryButton: ButtonStyle {
    func makeBody(configuration: Configuration) -> some View { configuration.label.font(.system(size: 12, weight: .semibold)).foregroundStyle(.white).padding(.horizontal, 12).padding(.vertical, 10).background(Theme.surfaceRaised.opacity(configuration.isPressed ? 0.7 : 1), in: RoundedRectangle(cornerRadius: 11)) }
}
