# Schwung Pocket v0.4.0

A native SwiftUI companion for Ableton Move running Schwung. Version 0.4 adds a Module Hub for user-defined shortcuts to known Schwung Manager pages, while retaining the Quick Control dashboard, Move Mirror, Sample & Set Vault, local metadata, audio previews and local snapshots.

## What's new in v0.4

- **Module Hub:** a dedicated tab with searchable shortcut cards for pages and tools you use most.
- **Starter shortcuts:** Schwung Manager and Move Mirror are included by default.
- **Custom shortcuts:** add a label, route or full HTTP(S) URL, icon and note. Shortcuts persist locally on the iPhone.
- **Quick connection check:** check whether the configured Move Manager address is reachable directly from the Hub.
- **Remove shortcuts:** long-press/context-menu a shortcut to delete it.
- **Build version:** 0.4.0 (build 4).

## Important limitation

The Hub does **not** automatically enumerate installed Schwung modules and does not claim to control instrument parameters. It opens routes or URLs that you explicitly provide. Use only routes you have verified in your own Schwung Manager. If Schwung later exposes a documented module list/API, the Hub can be extended to discover modules rather than relying on manual shortcuts.

## Existing features retained

- Home dashboard with configurable quick actions and connection status.
- Manager and Mirror embedded web views.
- Sample & Set Vault for files imported or downloaded onto the iPhone, with search, filters, audio preview where supported, tags, BPM, key and notes.
- Local timestamped snapshots, export, restore-to-library and delete.
- Connection checks while the app is active.

## What the Vault can and cannot do

The Vault manages files already imported or downloaded onto the iPhone. It does not crawl the Move filesystem and does not edit an Ableton Set in place. To protect a Move Set or sample, first download/export it through Schwung Manager or import it from iOS Files.

Restoring a snapshot makes a new local copy. It does **not** upload the file back to Move. Use Schwung Manager's supported upload/file features for transfers back to the device.

Audio preview uses Apple's AVAudioPlayer. It is intended for quick listening, not waveform editing or sample trimming. Codec support depends on iOS; `flac`, `ogg` and other formats may not preview in-app.

## Cloud build and IPA workflow

No Xcode installation is needed on your Mac when using the repository's existing GitHub Actions workflow:

1. Download this release ZIP.
2. Rename the downloaded archive to exactly `SchwungPocket-Starter.zip` if needed.
3. In your GitHub repository, replace the existing root-level `SchwungPocket-Starter.zip` with this archive using exactly that filename.
4. Leave the working `.github/workflows/build-ipa.yml` workflow unchanged.
5. Open **Actions → Compile iOS app in cloud → Run workflow**.
6. If the build succeeds, download the `SchwungPocket-unsigned-ipa` artifact and sign it using your existing iPhone sideloading method.

Replace the old ZIP rather than uploading alongside it, since some workflows may select the first archive with that name.

## Connection and network safety

- Default Manager address: `move.local:7700`.
- If `move.local` does not resolve, enter the Move's LAN IP and port `7700` in Settings.
- Use a trusted local network. Schwung Manager does not require a password; do not expose or port-forward its port to the public internet.
- Connection checks use the Manager URL, not undocumented privileged APIs.

## Validation status

Swift syntax parsing, Info.plist parsing and ZIP integrity checks were performed on the source package. This environment does not include Apple's iOS SDK, so a full compiler build and on-device test must still run in GitHub Actions. This ZIP is source for your existing cloud-build workflow, not a precompiled IPA.
