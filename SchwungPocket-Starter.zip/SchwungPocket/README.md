# Schwung Pocket v0.2.0

A native SwiftUI companion for Ableton Move running Schwung. This release adds quick-action favourites, foreground connection monitoring, and a local file Backup Vault while continuing to use the existing Schwung Manager for device-side features.

## What's new in v0.2

- **Customisable Quick Control dashboard:** choose among Manager, Screen Mirror, Backup Vault and Connection Settings shortcuts. Your selection is saved on the iPhone.
- **Automatic connection checks:** tests the Move connection when the app becomes active and retries every 25 seconds while the app remains in the foreground. iOS suspends most app work in the background, so this is not background monitoring.
- **Backup Vault:** lists files already saved in the app's `Documents/Downloads` folder, allows importing files from the iOS Files picker, creates timestamped local snapshots, restores a snapshot as a copy in Downloads, exports files through the iOS share sheet, and deletes snapshots with confirmation.
- **File visibility:** the Documents folder remains exposed through iOS Files using the existing document-sharing settings.
- **Build version:** 0.2.0 (build 2).

## Important limits of the Backup Vault

The Vault creates local snapshots of files already on the iPhone. It does **not** automatically crawl the Move filesystem, and it does not upload a restored file to Move. To back up a Set or other Move file, first download/export it through Schwung Manager, then create a snapshot in the Vault. Use the Manager interface to transfer a restored file back to Move if the relevant upload workflow is supported there.

## Cloud-build and IPA workflow

You do not need Xcode installed on your Mac when using the repository's working GitHub Actions workflow:

1. Download the updated `SchwungPocket-Starter.zip` supplied with this release.
2. In your GitHub repository, delete the current root-level `SchwungPocket-Starter.zip` and upload the new archive using **exactly the same filename**. The new archive contains the actual Xcode project directly, not another ZIP nested inside it.
3. Keep your working `.github/workflows/build-ipa.yml` workflow unchanged.
4. Open **Actions → Compile iOS app in cloud → Run workflow**.
5. When the build succeeds, download the `SchwungPocket-unsigned-ipa` artifact. Sign it with your chosen iOS sideloading workflow before installing it on your iPhone.

If the previous ZIP remains at the repository root, the workflow may select the old archive first and rebuild the old version. Replace it rather than uploading the new source under a different name.

## Build locally (optional)

1. Extract the ZIP.
2. Open `SchwungPocket/SchwungPocket.xcodeproj` in Xcode.
3. Configure Signing & Capabilities and run on an iPhone.

## Connection behaviour

- Default Manager address: `move.local:7700`.
- If `move.local` does not resolve on your network, enter the Move's LAN IP with port `7700` in Settings.
- Use a trusted local network. Schwung Manager does not require a password; do not port-forward its port to the public internet.
- Connection checks use the existing Manager URL and do not call undocumented privileged APIs.

## Project structure

- `SchwungPocketApp.swift`: application lifecycle and foreground monitoring.
- `ContentView.swift`: dashboard, favourites editor, Manager/Mirror tabs and connection settings.
- `MoveConnectionStore.swift`: stored address, connection status and foreground retry loop.
- `BackupVaultScreen.swift`: local file import, snapshot, restore, export and deletion.
- `ManagerWebView.swift`: embedded Schwung Manager and file download handling.
- `Theme.swift`: shared visual style.

## Validation

The Swift source files pass Swift parser validation, the property list and asset catalogue JSON pass structural validation, and the Xcode project references the new Backup Vault screen. A full Apple iOS compile and on-device test still needs to run through the cloud workflow. This archive itself is source code, not a prebuilt or signed IPA.
