# Schwung Pocket v0.4.1

Hotfix release addressing four reported v0.4.0 issues:

- Module Hub shortcuts now resolve origin-relative paths correctly, including `/` for the Schwung Manager home page.
- Quick Control editor supports reordering enabled shortcuts with the standard Edit control. The saved order is reflected on Home.
- JavaScript `confirm()` and `alert()` dialogs from Schwung Manager are presented as native iOS alerts. This restores confirmation prompts such as Update All before proceeding.
- Settings shows connection test status, explanatory result text, and the time of the latest test.

## Build

Upload this archive's `SchwungPocket/` folder contents into your existing repository using the same structure and keep the working GitHub Actions workflow unchanged. The archive is source code, not a compiled IPA. Run the existing cloud build workflow to create the unsigned IPA artifact, then sign/install it with your usual sideloading tool.

## Limitations

The connection test checks whether the configured manager address responds over HTTP(S). A reachable HTTP response does not guarantee every Schwung feature is functioning. Bulk-update confirmation depends on the Manager itself invoking JavaScript `confirm()`.
