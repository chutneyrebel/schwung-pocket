# Schwung Pocket v0.3.0

A native SwiftUI companion for Ableton Move running Schwung. Version 0.3 expands the on-device Vault into a sample and Set library, with audio preview, search, filters, metadata and the existing snapshot workflow.

## What's new in v0.3

- **Sample & Set Vault:** the former Backup Vault now includes a searchable local library for imported and downloaded audio, Ableton Sets and other project files.
- **Audio preview:** play/pause previews for common iOS-supported formats (`wav`, `aif`, `aiff`, `mp3`, `m4a`, `aac`, `caf`, `mp4`). Codec support still depends on iOS; a file that cannot be decoded will produce an error message.
- **Search and filters:** search filenames, tags, tempo, musical key and notes; filter by All, Audio, Sets or Other.
- **Sorting:** last modified, filename and largest first.
- **Musical metadata:** add comma-separated tags, tempo in BPM, musical key and notes to each library file. Metadata is stored locally in Application Support and does not modify the source file or Ableton Set.
- **Snapshots:** create timestamped local copies, export a snapshot, restore a copy to the library, and delete snapshots with confirmation.
- **Metadata preservation:** snapshots retain the file's local metadata; restoring a snapshot copies its metadata to the restored file.
- **Build version:** 0.3.0 (build 3).

## What the Vault can and cannot do

The Vault manages files already imported or downloaded onto the iPhone. It does not crawl the Move filesystem and does not edit an Ableton Set in place. To protect a Move Set or sample, first download/export it through Schwung Manager or import it from iOS Files.

Restoring a snapshot makes a new local copy. It does **not** upload the file back to Move. Use Schwung Manager's supported upload/file features for transfers back to the device.

Audio preview uses Apple's AVAudioPlayer. It is intended for quick listening, not waveform editing or sample trimming. `flac`, `ogg` and other formats may appear as audio files, but aren't offered an in-app preview by this version.

## Cloud build and IPA workflow

No Xcode installation is needed on your Mac when using the repository's existing GitHub Actions workflow:

1. Download the release ZIP supplied with this version.
2. Rename the downloaded archive to exactly `SchwungPocket-Starter.zip` if needed.
3. In your GitHub repository, delete the existing root-level `SchwungPocket-Starter.zip` and upload the new one using exactly that filename.
4. Leave the working `.github/workflows/build-ipa.yml` workflow unchanged.
5. Open **Actions → Compile iOS app in cloud → Run workflow**.
6. If the build succeeds, download the `SchwungPocket-unsigned-ipa` artifact and sign it using your current iPhone sideloading method.

Replace the old ZIP rather than uploading alongside it. Some workflows find the first archive by name and could otherwise build the previous version.

## Connection and safety

- Default Manager address: `move.local:7700`.
- If `move.local` does not resolve, enter the Move's LAN IP and port `7700` in Settings.
- Use a trusted local network. Schwung Manager does not require a password; do not expose or port-forward its port to the public internet.
- Connection checks use the Manager URL, not undocumented privileged APIs.

## Project structure

- `SchwungPocketApp.swift`: application lifecycle and foreground monitoring.
- `ContentView.swift`: quick-control dashboard, Manager/Mirror tabs and connection settings.
- `MoveConnectionStore.swift`: stored address, connection status and foreground retry loop.
- `ManagerWebView.swift`: embedded Schwung Manager and file download handling.
- `BackupVaultScreen.swift`: sample and Set library, audio previews, filters, file metadata, import/export and snapshots.
- `Theme.swift`: shared visual style.

## Validation status

Swift parser validation passed for all Swift source files. The Info.plist, asset-catalog JSON and project version markers were checked; the ZIP archive also passed integrity validation. This environment does not include Apple's iOS SDK, so a full compiler build and on-device test must still run in GitHub Actions.
